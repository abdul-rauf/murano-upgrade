<?php

$mod_strings = array_merge (return_module_language("en_us", "zr2_Report"),
	array (
	'LBL_MODULE_NAME' => 'Parameter Binding',
	'LBL_MODULE_TITLE' => 'Parameter Binding',

	'LBL_NAME' => 'Parameter Name',
	'LBL_PARAM_LINK_DEFAULTVALUE' => 'Default Value',
	'LBL_PARAM_LINK_PARAM' => 'Parameter Prompt',
	'LBL_PARAM_LINK_RANGE' => 'Selection',
	'LBL_PARAM_LINK_MODULENAME' => 'Bind to Module',
	)
);	
	
?>
