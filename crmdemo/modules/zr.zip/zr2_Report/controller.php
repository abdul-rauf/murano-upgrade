<?php

class zr2_ReportController extends SugarController 
{

	public function action_About()
	{
		$this->view="about";
		return true;
	}
}



?>
