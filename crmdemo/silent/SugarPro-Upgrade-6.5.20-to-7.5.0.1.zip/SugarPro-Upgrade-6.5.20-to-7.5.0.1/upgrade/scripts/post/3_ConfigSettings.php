<?php
 if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
/**
 * Update config.php settings
 */
class SugarUpgradeConfigSettings extends UpgradeScript
{
    public $order = 3000;
    public $type = self::UPGRADE_CUSTOM;

    public function run()
    {
        // Fill the missing settings.
        $defaultSettings = get_sugar_config_defaults();
        foreach ($defaultSettings as $key => $defaultValue) {

            if (!array_key_exists($key, $this->upgrader->config)) {
                $this->log("Setting $key does not exist. Setting the default value.");
                $this->upgrader->config[$key] = $defaultValue;
            }

        }

        $this->upgrader->config['sugar_version'] = $this->to_version;

	    if(!isset($this->upgrader->config['logger'])){
		    $this->upgrader->config['logger'] =array (
				'level'=>'fatal',
				'file' =>
				array (
						'ext' => '.log',
						'name' => 'sugarcrm',
						'dateFormat' => '%c',
						'maxSize' => '10MB',
						'maxLogs' => 10,
						'suffix' => '', // bug51583, change default suffix to blank for backwards comptability
				),
		    );
	    }

	    if (!isset($this->upgrader->config['lead_conv_activity_opt'])) {
	        $this->upgrader->config['lead_conv_activity_opt'] = 'copy';
	    }


        // We no longer have multiple themes support.

        // We removed the ability for the user to choose his preferred theme.
        // In the future, we'll add this feature back, in the new Sidecar Themes
        // format.
        // Backward compatibilty modules look and feel must be in accordance to
        // Sidecar modules, thus there is only one possible theme: `RacerX`
        $this->upgrader->config['default_theme'] = 'RacerX';
    }
}
