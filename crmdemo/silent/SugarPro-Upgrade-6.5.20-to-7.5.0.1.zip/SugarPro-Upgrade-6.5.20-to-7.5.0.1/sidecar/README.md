
# Easy Install

Sidecar requires [node.js](http://nodejs.org) to be installed.

**Make sure you install it with the `npm` package.**

Now install [uglify-js](https://github.com/mishoo/UglifyJS/) by running:

```bash
$ npm install uglify-js -g
```
