<?php
// created: 2014-12-12 10:09:00
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'PRO',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
      0 => '6.5.20.0',
    ),
    'regex_matches' => 
    array (
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarPro-Upgrade-6.5.20-to-7.5.0.1',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SugarPro',
  'published_date' => '2014-12-12 10:09:00',
  'type' => 'patch',
  'version' => '7.5.0.1',
  'flavor' => 'PRO',
);
?>
