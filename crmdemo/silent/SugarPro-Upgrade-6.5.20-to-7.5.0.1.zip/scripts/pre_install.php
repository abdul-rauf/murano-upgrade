<?php
echo "This version of SugarCRM requires use of the new upgrader script. Sugar 6.x upgrader can not be used to upgrade to this version.
Please contact SugarCRM support if you need more information.\n";
exit(1);
