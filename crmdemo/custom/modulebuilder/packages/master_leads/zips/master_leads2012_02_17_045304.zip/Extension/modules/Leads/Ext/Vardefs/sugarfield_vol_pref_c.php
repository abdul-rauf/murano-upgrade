<?php
 // created: 2011-09-08 11:08:42
$dictionary['Lead']['fields']['vol_pref_c']['dependency']='';

 ?>