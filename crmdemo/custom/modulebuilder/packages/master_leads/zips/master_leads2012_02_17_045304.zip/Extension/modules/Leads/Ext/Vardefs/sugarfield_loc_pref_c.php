<?php
 // created: 2011-09-08 11:06:46
$dictionary['Lead']['fields']['loc_pref_c']['dependency']='';

 ?>