<?php
 // created: 2011-05-18 11:53:39
$dictionary['Lead']['fields']['typ_invest_c']['enforced']='false';
$dictionary['Lead']['fields']['typ_invest_c']['dependency']='';

 ?>