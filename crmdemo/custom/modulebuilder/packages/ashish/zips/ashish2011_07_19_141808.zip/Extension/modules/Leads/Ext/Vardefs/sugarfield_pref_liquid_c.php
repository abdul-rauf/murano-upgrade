<?php
 // created: 2011-05-19 17:12:05
$dictionary['Lead']['fields']['pref_liquid_c']['dependency']='';

 ?>