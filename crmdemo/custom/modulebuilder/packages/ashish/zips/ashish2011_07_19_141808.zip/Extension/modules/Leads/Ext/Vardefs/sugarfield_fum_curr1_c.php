<?php
 // created: 2011-05-19 17:10:17
$dictionary['Lead']['fields']['fum_curr1_c']['dependency']='';

 ?>