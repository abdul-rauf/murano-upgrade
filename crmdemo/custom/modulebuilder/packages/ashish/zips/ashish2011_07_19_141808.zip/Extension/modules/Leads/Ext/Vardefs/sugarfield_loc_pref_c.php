<?php
 // created: 2011-05-18 12:14:20
$dictionary['Lead']['fields']['loc_pref_c']['dependency']='';

 ?>