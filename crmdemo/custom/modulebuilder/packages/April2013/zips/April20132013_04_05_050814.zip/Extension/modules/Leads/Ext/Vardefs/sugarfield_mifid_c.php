<?php
 // created: 2013-01-28 14:48:39
$dictionary['Lead']['fields']['mifid_c']['dependency']='';
$dictionary['Lead']['fields']['mifid_c']['visibility_grid']='';

 ?>