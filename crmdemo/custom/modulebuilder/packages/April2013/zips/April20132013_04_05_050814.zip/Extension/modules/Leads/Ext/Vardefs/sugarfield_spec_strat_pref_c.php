<?php
 // created: 2011-09-08 11:12:41
$dictionary['Lead']['fields']['spec_strat_pref_c']['dependency']='';

 ?>