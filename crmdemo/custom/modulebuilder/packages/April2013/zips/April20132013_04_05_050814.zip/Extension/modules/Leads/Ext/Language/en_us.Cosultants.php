<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_MR_CONSULTANT_LEADS_FROM_MR_CONSULTANT_TITLE'] = 'Consultants';
$mod_strings['LBL_CONSULTANTS'] = 'Consultants';


