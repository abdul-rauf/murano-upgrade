<?php
 // created: 2012-03-05 19:05:39
$layout_defs["Leads"]["subpanel_setup"]['cl_client_list_leads_1'] = array (
  'order' => 100,
  'module' => 'cl_Client_list',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CL_CLIENT_LIST_LEADS_1_FROM_CL_CLIENT_LIST_TITLE',
  'get_subpanel_data' => 'cl_client_list_leads_1',
);
