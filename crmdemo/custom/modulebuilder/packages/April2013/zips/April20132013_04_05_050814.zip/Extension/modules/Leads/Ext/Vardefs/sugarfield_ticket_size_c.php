<?php
 // created: 2012-03-05 15:00:30
$dictionary['Lead']['fields']['ticket_size_c']['enforced']='false';
$dictionary['Lead']['fields']['ticket_size_c']['dependency']='';

 ?>