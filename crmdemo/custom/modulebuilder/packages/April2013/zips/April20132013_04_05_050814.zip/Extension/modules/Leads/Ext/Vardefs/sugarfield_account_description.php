<?php
 // created: 2012-02-09 12:04:24
$dictionary['Lead']['fields']['account_description']['calculated']=false;
$dictionary['Lead']['fields']['account_description']['rows']='10';
$dictionary['Lead']['fields']['account_description']['cols']='80';

 ?>