<?php
 // created: 2013-01-23 12:05:04
$dictionary['Lead']['fields']['affiliate_c']['enforced']='';
$dictionary['Lead']['fields']['affiliate_c']['dependency']='';

 ?>