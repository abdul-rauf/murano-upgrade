<?php
 // created: 2012-02-09 12:03:46
$dictionary['Lead']['fields']['description']['calculated']=false;
$dictionary['Lead']['fields']['description']['rows']='20';

 ?>