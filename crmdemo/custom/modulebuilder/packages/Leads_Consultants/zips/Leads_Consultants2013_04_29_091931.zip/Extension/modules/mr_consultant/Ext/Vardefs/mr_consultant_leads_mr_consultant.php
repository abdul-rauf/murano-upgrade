<?php
// created: 2012-12-18 14:50:26
$dictionary["mr_consultant"]["fields"]["mr_consultant_leads"] = array (
  'name' => 'mr_consultant_leads',
  'type' => 'link',
  'relationship' => 'mr_consultant_leads',
  'source' => 'non-db',
  'vname' => 'LBL_MR_CONSULTANT_LEADS_FROM_LEADS_TITLE',
);
