<?php
 // created: 2011-05-18 13:51:41
$dictionary['Lead']['fields']['req_aum_c']['enforced']='false';
$dictionary['Lead']['fields']['req_aum_c']['dependency']='';

 ?>