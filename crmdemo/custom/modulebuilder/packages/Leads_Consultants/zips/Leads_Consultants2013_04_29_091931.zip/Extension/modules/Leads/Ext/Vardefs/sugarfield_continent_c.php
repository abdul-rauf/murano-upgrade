<?php
 // created: 2012-07-10 08:50:27
$dictionary['Lead']['fields']['continent_c']['dependency']='';

 ?>