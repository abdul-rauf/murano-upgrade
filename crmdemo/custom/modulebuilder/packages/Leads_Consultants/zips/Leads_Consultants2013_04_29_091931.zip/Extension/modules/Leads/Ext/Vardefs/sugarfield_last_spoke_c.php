<?php
 // created: 2013-01-21 14:00:25
$dictionary['Lead']['fields']['last_spoke_c']['enforced']='';
$dictionary['Lead']['fields']['last_spoke_c']['dependency']='';

 ?>