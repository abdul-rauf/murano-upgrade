<?php 
 // created: 2011-01-04 15:14:26
$mod_strings['LBL_ACCOUNT_NAME'] = 'Account Name';
$mod_strings['LBL_FSA'] = 'FSA';
$mod_strings['LBL_LAST_NAME'] = 'Last Name:';

?>
