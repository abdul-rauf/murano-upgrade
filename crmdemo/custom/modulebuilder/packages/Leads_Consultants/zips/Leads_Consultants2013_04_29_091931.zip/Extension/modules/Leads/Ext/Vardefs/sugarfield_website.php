<?php
 // created: 2011-07-12 10:34:08
$dictionary['Lead']['fields']['website']['calculated']=false;
$dictionary['Lead']['fields']['website']['link_target']='_blank';
$dictionary['Lead']['fields']['website']['default']='';

 ?>