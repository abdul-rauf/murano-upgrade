<?php
 // created: 2012-12-18 14:50:26
$layout_defs["mr_consultant"]["subpanel_setup"]['mr_consultant_leads'] = array (
  'order' => 100,
  'module' => 'Leads',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_MR_CONSULTANT_LEADS_FROM_LEADS_TITLE',
  'get_subpanel_data' => 'mr_consultant_leads',
);
