<?php
 // created: 2012-02-09 12:05:24
$dictionary['Lead']['fields']['further_information_c']['enforced']='false';
$dictionary['Lead']['fields']['further_information_c']['dependency']='';

 ?>