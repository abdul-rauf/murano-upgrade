<?php
 // created: 2012-04-24 14:06:19
$dictionary['Lead']['fields']['loc_pref_c']['dependency']='';

 ?>