<?php
 // created: 2011-05-25 16:17:22
$dictionary['Lead']['fields']['account_name']['calculated']=false;
$dictionary['Lead']['fields']['account_name']['merge_filter']='enabled';

 ?>