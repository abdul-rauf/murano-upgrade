<?php
 // created: 2011-09-08 11:13:52
$dictionary['Lead']['fields']['investor_typ_c']['dependency']='';

 ?>