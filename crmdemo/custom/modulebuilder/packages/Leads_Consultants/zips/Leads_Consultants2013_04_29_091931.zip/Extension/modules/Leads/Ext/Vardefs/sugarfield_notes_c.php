<?php
 // created: 2012-02-09 12:06:18
$dictionary['Lead']['fields']['notes_c']['enforced']='false';
$dictionary['Lead']['fields']['notes_c']['dependency']='';

 ?>