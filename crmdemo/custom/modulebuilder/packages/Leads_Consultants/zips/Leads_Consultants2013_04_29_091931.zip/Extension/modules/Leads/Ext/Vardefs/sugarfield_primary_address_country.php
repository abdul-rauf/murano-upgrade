<?php
 // created: 2012-07-10 12:29:07
$dictionary['Lead']['fields']['primary_address_country']['calculated']=false;

 ?>