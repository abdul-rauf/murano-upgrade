<?php
// created: 2011-02-04 10:45:47
$dictionary["Account"]["fields"]["accounts_accounts_2"] = array (
  'name' => 'accounts_accounts_2',
  'type' => 'link',
  'relationship' => 'accounts_accounts_2',
  'source' => 'non-db',
  'vname' => 'LBL_ACCOUNTS_ACCOUNTS_2_FROM_ACCOUNTS_L_TITLE',
);
$dictionary["Account"]["fields"]["accounts_accounts_2_name"] = array (
  'name' => 'accounts_accounts_2_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ACCOUNTS_ACCOUNTS_2_FROM_ACCOUNTS_L_TITLE',
  'save' => true,
  'id_name' => 'accounts_a79d3ccounts_ida',
  'link' => 'accounts_accounts_2',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
$dictionary["Account"]["fields"]["accounts_a79d3ccounts_ida"] = array (
  'name' => 'accounts_a79d3ccounts_ida',
  'type' => 'link',
  'relationship' => 'accounts_accounts_2',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_ACCOUNTS_ACCOUNTS_2_FROM_ACCOUNTS_R_TITLE',
);
