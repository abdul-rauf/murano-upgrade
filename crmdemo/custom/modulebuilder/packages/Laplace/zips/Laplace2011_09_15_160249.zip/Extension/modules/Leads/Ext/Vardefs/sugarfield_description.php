<?php
 // created: 2011-01-20 14:13:43
$dictionary['Lead']['fields']['description']['calculated']=false;
$dictionary['Lead']['fields']['description']['rows']='20';

 ?>