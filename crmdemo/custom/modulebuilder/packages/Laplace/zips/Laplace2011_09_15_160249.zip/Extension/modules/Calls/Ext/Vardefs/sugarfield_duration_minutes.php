<?php
 // created: 2011-02-16 11:35:09
$dictionary['Call']['fields']['duration_minutes']['importable']='true';
$dictionary['Call']['fields']['duration_minutes']['calculated']=false;

 ?>