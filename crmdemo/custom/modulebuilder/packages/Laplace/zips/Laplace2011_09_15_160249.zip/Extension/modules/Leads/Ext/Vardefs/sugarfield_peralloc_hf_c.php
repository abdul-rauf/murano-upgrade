<?php
 // created: 2011-07-12 10:16:29
$dictionary['Lead']['fields']['peralloc_hf_c']['enforced']='false';
$dictionary['Lead']['fields']['peralloc_hf_c']['dependency']='';

 ?>