<?php
 // created: 2011-02-16 11:35:20
$dictionary['Call']['fields']['duration_hours']['required']=false;
$dictionary['Call']['fields']['duration_hours']['calculated']=false;

 ?>