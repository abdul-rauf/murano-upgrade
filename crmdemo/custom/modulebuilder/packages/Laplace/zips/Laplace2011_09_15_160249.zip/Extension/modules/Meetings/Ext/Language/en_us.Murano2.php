<?php 
 // created: 2011-05-12 19:35:31
$mod_strings['LBL_DATE'] = 'Start Date:';
$mod_strings['LBL_DURATION_MINUTES'] = 'Duration Minutes:';
$mod_strings['LBL_DURATION_HOURS'] = 'Duration Hours:';

?>
