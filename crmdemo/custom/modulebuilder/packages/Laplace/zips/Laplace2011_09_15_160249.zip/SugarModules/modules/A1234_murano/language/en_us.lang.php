<?php 
 // created: 2011-09-15 16:02:39
$mod_strings['LBL_MURANO'] = 'murano';

?>
