<?php
$searchdefs ['Accounts'] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'current_user_only' => 
      array (
        'name' => 'current_user_only',
        'label' => 'LBL_CURRENT_USER_FILTER',
        'type' => 'bool',
        'default' => true,
        'width' => '10%',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'website' => 
      array (
        'name' => 'website',
        'default' => true,
        'width' => '10%',
      ),
      'address_city' => 
      array (
        'name' => 'address_city',
        'label' => 'LBL_CITY',
        'type' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'address_state' => 
      array (
        'name' => 'address_state',
        'label' => 'LBL_STATE',
        'type' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'penalty_c' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_PENALTY',
        'width' => '10%',
        'name' => 'penalty_c',
      ),
      'leverage_c' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_LEVERAGE',
        'width' => '10%',
        'name' => 'leverage_c',
      ),
      'lockuptickifyes_c' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_LOCKUPTICKIFYES',
        'width' => '10%',
        'name' => 'lockuptickifyes_c',
      ),
      'companytype_c' => 
      array (
        'type' => 'multienum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_COMPANYTYPE',
        'width' => '10%',
        'name' => 'companytype_c',
      ),
      'subscriptionfrequency_c' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_SUBSCRIPTIONFREQUENCY',
        'sortable' => false,
        'width' => '10%',
        'name' => 'subscriptionfrequency_c',
      ),
      'redemptionfrequency_c' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_REDEMPTIONFREQUENCY',
        'sortable' => false,
        'width' => '10%',
        'name' => 'redemptionfrequency_c',
      ),
      'regionallocation_c' => 
      array (
        'type' => 'multienum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_REGIONALLOCATION',
        'width' => '10%',
        'name' => 'regionallocation_c',
      ),
      'currentallocationtohf_c' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_CURRENTALLOCATIONTOHF',
        'sortable' => false,
        'width' => '10%',
        'name' => 'currentallocationtohf_c',
      ),
      'targetallocationtohf_c' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_TARGETALLOCATIONTOHF',
        'sortable' => false,
        'width' => '10%',
        'name' => 'targetallocationtohf_c',
      ),
      'currentlocationofinterest_c' => 
      array (
        'type' => 'multienum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_CURRENTLOCATIONOFINTEREST',
        'width' => '10%',
        'name' => 'currentlocationofinterest_c',
      ),
      'currentstrategyofinterest_c' => 
      array (
        'type' => 'multienum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_CURRENTSTRATEGYOFINTEREST',
        'width' => '10%',
        'name' => 'currentstrategyofinterest_c',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
