<?php
// created: 2010-12-14 16:08:03
$layout_defs["Documents"]["subpanel_setup"]["accounts_documents"] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ACCOUNTS_DOCUMENTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'accounts_documents',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
