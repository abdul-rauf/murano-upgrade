<?php 
 // created: 2011-02-09 16:41:02
$mod_strings['LBL_NOTES'] = 'Notes';
$mod_strings['LBL_INVESTMENT_GEOGRAPHY'] = 'Investment Geography';
$mod_strings['LBL_INVESTMENTGEOGRAPHY'] = 'Investment Geography text';
$mod_strings['LBL_FUND_STRATEGY'] = 'Fund Strategy';
$mod_strings['LBL_FUNDSTRATEGY'] = 'Fund StrategyDD';
$mod_strings['LBL_ADDITIONALINFORMATION'] = 'Additional Information';
$mod_strings['LBL_NEWS_LINKS'] = 'News Links';
$mod_strings['LBL_DESCRIPTION'] = 'Description:';
$mod_strings['LBL_SHARPERATIOTRIAL'] = 'sharperatiotrial';
$mod_strings['LBL_SORTINORATIOTRIAL'] = 'sortinoratiotrial';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'Perfecta Management & Fund Information';
$mod_strings['LBL_DETAILVIEW_PANEL2'] = 'Location';
$mod_strings['LBL_PANEL_ADVANCED'] = 'Management & Fund Information';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Location';
$mod_strings['LBL_PERFECTASTRATEGY'] = 'Perfecta Fund Strategy';
$mod_strings['LBL_EDITVIEW_PANEL3'] = 'New Panel 3';
$mod_strings['LBL_EDITVIEW_PANEL4'] = 'Location';
$mod_strings['LBL_AUM2'] = 'Aum ($mil)b';
$mod_strings['LBL_DETAILVIEW_PANEL3'] = 'Perfecta Management & Fund Information';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'Location';
$mod_strings['LBL_NEWSPAPERINFORMATION'] = 'Newspaper Information';

?>
