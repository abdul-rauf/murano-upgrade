<?php
// created: 2010-12-14 16:08:10
$dictionary["Account"]["fields"]["accounts_documents_1"] = array (
  'name' => 'accounts_documents_1',
  'type' => 'link',
  'relationship' => 'accounts_documents_1',
  'source' => 'non-db',
  'vname' => 'LBL_ACCOUNTS_DOCUMENTS_1_FROM_DOCUMENTS_TITLE',
);
