<?php
// created: 2011-02-17 12:45:47
$dictionary["Call"]["fields"]["a_acontact_calls"] = array (
  'name' => 'a_acontact_calls',
  'type' => 'link',
  'relationship' => 'a_acontact_calls',
  'source' => 'non-db',
  'vname' => 'LBL_A_ACONTACT_CALLS_FROM_A_ACONTACT_TITLE',
);
$dictionary["Call"]["fields"]["a_acontact_calls_name"] = array (
  'name' => 'a_acontact_calls_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_A_ACONTACT_CALLS_FROM_A_ACONTACT_TITLE',
  'save' => true,
  'id_name' => 'a_acontact4399contact_ida',
  'link' => 'a_acontact_calls',
  'table' => 'a_acontact',
  'module' => 'A_AContact',
  'rname' => 'name',
);
$dictionary["Call"]["fields"]["a_acontact4399contact_ida"] = array (
  'name' => 'a_acontact4399contact_ida',
  'type' => 'link',
  'relationship' => 'a_acontact_calls',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_A_ACONTACT_CALLS_FROM_CALLS_TITLE',
);
