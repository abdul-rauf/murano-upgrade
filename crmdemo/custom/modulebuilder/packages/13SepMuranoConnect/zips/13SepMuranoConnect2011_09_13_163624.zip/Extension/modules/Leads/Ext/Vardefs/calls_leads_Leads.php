<?php
// created: 2011-02-07 10:52:58
$dictionary["Lead"]["fields"]["calls_leads"] = array (
  'name' => 'calls_leads',
  'type' => 'link',
  'relationship' => 'calls_leads',
  'source' => 'non-db',
  'vname' => 'LBL_CALLS_LEADS_FROM_CALLS_TITLE',
);
