<?php 
 // created: 2011-09-13 16:36:11
$mod_strings['LBL_MURANO'] = 'murano';

?>
