<?php
// created: 2018-02-16 15:48:20
$viewdefs['rt_sorting']['base']['filter']['default'] = array (
  'default_filter' => 'all_records',
  'fields' => 
  array (
    'da_confirmed_clients_c' => 
    array (
    ),
    'da_qm_clients_c' => 
    array (
    ),
    'da_feedback_clients_c' => 
    array (
    ),
    'confirmed_clients' => 
    array (
    ),
    'question_marks' => 
    array (
    ),
    'date_entered' => 
    array (
    ),
    'date_modified' => 
    array (
    ),
    'assigned_user_name' => 
    array (
    ),
    '$owner' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_CURRENT_USER_FILTER',
    ),
    '$favorite' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_FAVORITES_FILTER',
    ),
    'feedback_date1_c' => 
    array (
    ),
    'feedback_received_c' => 
    array (
    ),
    'modified_by_name' => 
    array (
    ),
    'assigned_team' => 
    array (
    ),
  ),
);