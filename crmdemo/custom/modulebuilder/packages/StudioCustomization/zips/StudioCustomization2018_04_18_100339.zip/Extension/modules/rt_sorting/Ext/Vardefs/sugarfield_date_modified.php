<?php
 // created: 2018-01-16 14:25:39
$dictionary['rt_sorting']['fields']['date_modified']['audited']=true;
$dictionary['rt_sorting']['fields']['date_modified']['comments']='Date record last modified';
$dictionary['rt_sorting']['fields']['date_modified']['duplicate_merge']='enabled';
$dictionary['rt_sorting']['fields']['date_modified']['duplicate_merge_dom_value']=1;
$dictionary['rt_sorting']['fields']['date_modified']['merge_filter']='disabled';
$dictionary['rt_sorting']['fields']['date_modified']['unified_search']=false;
$dictionary['rt_sorting']['fields']['date_modified']['calculated']=false;

 ?>