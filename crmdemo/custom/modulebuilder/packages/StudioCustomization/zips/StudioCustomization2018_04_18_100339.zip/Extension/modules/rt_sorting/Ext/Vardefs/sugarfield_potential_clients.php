<?php
 // created: 2017-12-20 09:06:00
$dictionary['rt_sorting']['fields']['potential_clients']['help']='***This is a list of only clients with active CRM';

 ?>