<?php
 // created: 2018-01-24 10:20:44
$dictionary['rt_sorting']['fields']['da_qm_clients_c']['labelValue']='DA Question Marks';
$dictionary['rt_sorting']['fields']['da_qm_clients_c']['dependency']='';
$dictionary['rt_sorting']['fields']['da_qm_clients_c']['visibility_grid']='';

 ?>