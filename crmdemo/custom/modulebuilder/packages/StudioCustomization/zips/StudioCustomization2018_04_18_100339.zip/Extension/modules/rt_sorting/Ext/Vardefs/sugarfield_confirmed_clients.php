<?php
 // created: 2018-01-16 14:24:20
$dictionary['rt_sorting']['fields']['confirmed_clients']['help']='***This is clients you have selected from Potential List and you will intend to send report to these clients';
$dictionary['rt_sorting']['fields']['confirmed_clients']['cols']='10';
$dictionary['rt_sorting']['fields']['confirmed_clients']['audited']=true;
$dictionary['rt_sorting']['fields']['confirmed_clients']['full_text_search']=array (
);

 ?>