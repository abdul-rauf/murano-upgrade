<?php
 // created: 2018-01-24 10:20:19
$dictionary['rt_sorting']['fields']['da_confirmed_clients_c']['labelValue']='DA Confirmed Clients';
$dictionary['rt_sorting']['fields']['da_confirmed_clients_c']['dependency']='';
$dictionary['rt_sorting']['fields']['da_confirmed_clients_c']['visibility_grid']='';

 ?>