<?php
 // created: 2018-01-16 14:22:34
$dictionary['rt_sorting']['fields']['lead_status']['default']='follow_up';
$dictionary['rt_sorting']['fields']['lead_status']['help']='***Is your report a "New" or "Follow Up"?';
$dictionary['rt_sorting']['fields']['lead_status']['audited']=true;

 ?>