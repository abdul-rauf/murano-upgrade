<?php
 // created: 2018-02-13 13:40:56
$dictionary['rt_sorting']['fields']['ref_id_c']['labelValue']='Ref';
$dictionary['rt_sorting']['fields']['ref_id_c']['enforced']='1';
$dictionary['rt_sorting']['fields']['ref_id_c']['dependency']='';

 ?>