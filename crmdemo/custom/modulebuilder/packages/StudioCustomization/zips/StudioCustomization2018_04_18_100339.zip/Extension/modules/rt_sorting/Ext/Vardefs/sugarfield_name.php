<?php
 // created: 2017-12-15 16:24:13
$dictionary['rt_sorting']['fields']['name']['help']='*** This will auto-fill. Ignore this.';
$dictionary['rt_sorting']['fields']['name']['unified_search']=false;
$dictionary['rt_sorting']['fields']['name']['full_text_search']=array (
);

 ?>