<?php
 // created: 2017-12-20 09:27:01
$dictionary['rt_sorting']['fields']['amendments_completed_c']['labelValue']='Completed Amendments';
$dictionary['rt_sorting']['fields']['amendments_completed_c']['enforced']='';
$dictionary['rt_sorting']['fields']['amendments_completed_c']['dependency']='';

 ?>