<?php
 // created: 2017-12-15 16:12:22
$dictionary['rt_sorting']['fields']['feedback_received_c']['labelValue']='Feedback Received';
$dictionary['rt_sorting']['fields']['feedback_received_c']['full_text_search']=array (
  'boost' => '0',
  'enabled' => false,
);
$dictionary['rt_sorting']['fields']['feedback_received_c']['enforced']='';
$dictionary['rt_sorting']['fields']['feedback_received_c']['dependency']='';

 ?>