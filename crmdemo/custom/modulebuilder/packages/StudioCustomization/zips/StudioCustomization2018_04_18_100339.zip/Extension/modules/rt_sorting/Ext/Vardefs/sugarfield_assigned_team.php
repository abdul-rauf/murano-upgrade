<?php
 // created: 2018-01-16 14:25:10
$dictionary['rt_sorting']['fields']['assigned_team']['help']='***This field will auto-fill the Subject';
$dictionary['rt_sorting']['fields']['assigned_team']['audited']=true;

 ?>