<?php
 // created: 2018-01-16 14:23:12
$dictionary['rt_sorting']['fields']['feedback_date1_c']['labelValue']='Completed Feedback Date';
$dictionary['rt_sorting']['fields']['feedback_date1_c']['enforced']='';
$dictionary['rt_sorting']['fields']['feedback_date1_c']['dependency']='';

 ?>