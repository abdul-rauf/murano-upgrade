<?php
 // created: 2018-02-26 16:27:07
$dictionary['rt_report_board']['fields']['week_c']['labelValue']='No of Week';
$dictionary['rt_report_board']['fields']['week_c']['full_text_search']=array (
  'boost' => '0',
  'enabled' => false,
);
$dictionary['rt_report_board']['fields']['week_c']['enforced']='';
$dictionary['rt_report_board']['fields']['week_c']['dependency']='';

 ?>