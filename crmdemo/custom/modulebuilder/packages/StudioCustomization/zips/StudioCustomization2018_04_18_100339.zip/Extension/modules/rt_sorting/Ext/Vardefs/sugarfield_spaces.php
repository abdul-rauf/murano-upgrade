<?php
 // created: 2017-12-15 16:25:59
$dictionary['rt_sorting']['fields']['spaces']['help']='*** Estimate how many spaces will this go to?';

 ?>