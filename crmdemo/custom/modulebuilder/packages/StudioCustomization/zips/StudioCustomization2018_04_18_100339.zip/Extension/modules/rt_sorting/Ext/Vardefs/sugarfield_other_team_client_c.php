<?php
 // created: 2018-02-12 16:36:02
$dictionary['rt_sorting']['fields']['other_team_client_c']['labelValue']='Other Team Client?';
$dictionary['rt_sorting']['fields']['other_team_client_c']['enforced']='';
$dictionary['rt_sorting']['fields']['other_team_client_c']['dependency']='';

 ?>