<?php
 // created: 2018-02-15 16:55:23
$dictionary['rt_sorting']['fields']['report_status']['comments']='';
$dictionary['rt_sorting']['fields']['report_status']['help']='***Not Ready - You do not want anyone to see it, but only yourself. ***Ready for Team ? -  You want Team ? to see it.  ***Ready to Amend - The report sorting is finished and you want the report owner to finalise it to send to client. ***Send - Report has been sent. ';
$dictionary['rt_sorting']['fields']['report_status']['audited']=true;

 ?>