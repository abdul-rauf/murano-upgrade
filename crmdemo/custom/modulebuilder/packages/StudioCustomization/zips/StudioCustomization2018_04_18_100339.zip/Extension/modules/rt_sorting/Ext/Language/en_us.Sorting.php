<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_RT_SORTING_LEADS_FROM_LEADS_TITLE'] = 'Name';
$mod_strings['LBL_RT_SORTING_LEADS_FROM_RT_SORTING_TITLE_ID'] = 'Leads ID';
$mod_strings['LBL_COMPOSE_CLIENT'] = 'Compose To Clients';
$mod_strings['LBL_RECENT_TIME_CHANGED'] = 'Recent Time Changed';
