<?php
 // created: 2018-02-07 09:25:45
$dictionary['rt_sorting']['fields']['da_feedback_clients_c']['labelValue']='DA Feedback Clients';
$dictionary['rt_sorting']['fields']['da_feedback_clients_c']['dependency']='';
$dictionary['rt_sorting']['fields']['da_feedback_clients_c']['visibility_grid']='';

 ?>