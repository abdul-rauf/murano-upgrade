<?php
 // created: 2018-01-16 14:22:50
$dictionary['rt_sorting']['fields']['greenreport_c']['labelValue']='Green Report?';
$dictionary['rt_sorting']['fields']['greenreport_c']['enforced']='';
$dictionary['rt_sorting']['fields']['greenreport_c']['dependency']='';

 ?>