<?php
 // created: 2018-01-16 14:24:37
$dictionary['rt_sorting']['fields']['question_marks']['help']='***This is clients in question. You can also add commentary. e.g.  Cloud5? (Will to check)';
$dictionary['rt_sorting']['fields']['question_marks']['audited']=true;
$dictionary['rt_sorting']['fields']['question_marks']['full_text_search']=array (
);

 ?>