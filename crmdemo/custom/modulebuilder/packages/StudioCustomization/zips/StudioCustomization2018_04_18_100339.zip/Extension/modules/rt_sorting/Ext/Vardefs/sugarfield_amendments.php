<?php
 // created: 2017-12-20 09:27:32
$dictionary['rt_sorting']['fields']['amendments']['full_text_search']=array (
);

 ?>