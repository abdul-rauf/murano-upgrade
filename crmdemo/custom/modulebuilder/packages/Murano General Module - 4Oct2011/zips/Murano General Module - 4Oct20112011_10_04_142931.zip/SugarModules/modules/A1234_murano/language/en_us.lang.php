<?php 
 // created: 2011-10-04 14:29:17
$mod_strings['LBL_MURANO'] = 'murano';

?>
