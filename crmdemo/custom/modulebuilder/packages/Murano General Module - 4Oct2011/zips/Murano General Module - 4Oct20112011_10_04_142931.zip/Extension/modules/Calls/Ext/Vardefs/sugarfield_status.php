<?php
 // created: 2011-02-23 11:47:14
$dictionary['Call']['fields']['status']['default']='Held';
$dictionary['Call']['fields']['status']['importable']='true';
$dictionary['Call']['fields']['status']['calculated']=false;
$dictionary['Call']['fields']['status']['dependency']=false;

 ?>