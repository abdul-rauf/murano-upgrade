<?php
 // created: 2011-09-08 11:09:41
$dictionary['Lead']['fields']['allocating_c']['dependency']='';

 ?>