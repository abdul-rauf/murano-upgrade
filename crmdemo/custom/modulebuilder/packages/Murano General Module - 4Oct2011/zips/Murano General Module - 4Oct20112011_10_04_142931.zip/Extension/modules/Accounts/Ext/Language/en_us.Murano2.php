<?php 
 // created: 2011-05-12 19:35:29
$mod_strings['LBL_REGIONALLOCATION'] = 'Regional Location';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Location';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'Location';

?>
