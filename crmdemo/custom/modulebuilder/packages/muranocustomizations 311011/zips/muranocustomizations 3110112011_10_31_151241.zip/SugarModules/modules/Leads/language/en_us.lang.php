<?php 
 // created: 2011-10-31 15:12:33
$mod_strings['LBL_DESCRIPTION'] = 'Investment Allocation Details';
$mod_strings['LBL_OWNERSHIP'] = 'Investment Information';
$mod_strings['LBL_FUNDSTRATEGY'] = 'Investor Type';
$mod_strings['LBL_FURTHER_INFORMATION'] = 'Company Description';
$mod_strings['LBL_ACCOUNT_DESCRIPTION'] = 'Notes';
$mod_strings['LBL_NOTES'] = 'Investment Description';
$mod_strings['LBL_AUM'] = 'FuM (Million)';
$mod_strings['(EMPTY)'] = '';
$mod_strings['LBL_AUM1'] = 'FuM Currency';
$mod_strings['LBL_FUM_CURR'] = 'FuM Currency';
$mod_strings['LBL_FUM_CURR1'] = 'FuM Currency';
$mod_strings['LBL_FUND_TYPE'] = 'General Strategy Preferences';
$mod_strings['LBL_PERALLOC_HF'] = 'Hedge Fund Allocation (%)';
$mod_strings['LBL_TYP_INVEST'] = 'Typical Investment ($mil)';
$mod_strings['LBL_LOC_PREF'] = 'Location Preferences';
$mod_strings['LBL_VOL_PREF'] = 'Volatility Preference';
$mod_strings['LBL_ALLOCATING'] = 'Allocating';
$mod_strings['LBL_CURRENT_STRAT'] = 'Current Strategy';
$mod_strings['LBL_REQ_AUM'] = 'Required Fund AuM';
$mod_strings['LBL_ALLOC_FOHFS'] = 'Allocating to FoHFs';
$mod_strings['LBL_MIN_TRACK'] = 'Minimum Track Record';
$mod_strings['LBL_PREF_LIQUID'] = 'Preferred Liquidity';
$mod_strings['LBL_TYPCOM_SIZE'] = 'Typical Commitment Size';
$mod_strings['LBL_INVESTOR_TYP'] = 'Investor Type';
$mod_strings['LBL_SPEC_STRAT_PREF'] = 'Specific Strategy Preferences';
$mod_strings['LBL_TARG_RETURN'] = 'Target Return (%)';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Account Name';
$mod_strings['LBL_AVG_TIME_MONITORED'] = 'Average Time Fund Monitored (months)';
$mod_strings['LBL_WEBSITE'] = 'Website';
$mod_strings['LBL_INVESTOR_RANK'] = 'Investor ranking';
$mod_strings['LBL_INVESTOR_RATING'] = 'Investor Rating';
$mod_strings['LBL_RATING'] = 'rating';
$mod_strings['LBL_DETAILVIEW_PANEL2'] = 'New Panel 2';
$mod_strings['LBL_INVESTMENT_GEOGRAPHY'] = 'Investment Geography';
$mod_strings['LBL_OTHER_PHONE'] = 'Other Phone';

?>
