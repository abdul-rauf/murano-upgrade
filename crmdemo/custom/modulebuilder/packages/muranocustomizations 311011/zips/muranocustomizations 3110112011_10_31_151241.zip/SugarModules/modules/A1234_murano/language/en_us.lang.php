<?php 
 // created: 2011-10-31 15:12:24
$mod_strings['LBL_MURANO'] = 'murano';

?>
