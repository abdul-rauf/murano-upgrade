<?php
 // created: 2011-09-08 11:07:26
$dictionary['Lead']['fields']['investment_geography_c']['dependency']='';

 ?>