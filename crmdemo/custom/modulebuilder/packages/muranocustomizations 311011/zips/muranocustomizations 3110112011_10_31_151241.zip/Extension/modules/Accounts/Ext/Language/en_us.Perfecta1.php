<?php 
 // created: 2011-01-04 15:14:23
$mod_strings['LBL_FUNDNAME'] = 'Fund Name';
$mod_strings['LBL_OTHERINFORMATION'] = 'Other Information';
$mod_strings['LBL_BRIEFSUMMARY'] = 'Brief Summary';
$mod_strings['LBL_FUNDMANAGER '] = 'Fund Manager ';
$mod_strings['LBL_NEWSPAPERINFORMATION'] = 'Newspaper Information';
$mod_strings['LBL_AUM'] = 'AuM($mil)';
$mod_strings['LBL_INTEREST'] = 'Interest in Expanding';
$mod_strings['LBL_INVESTMENTGEOGRAPHY'] = 'Investment Geography';
$mod_strings['LBL_BILLING_ADDRESS_STREET'] = 'Street:';
$mod_strings['LBL_BILLING_ADDRESS_POSTALCODE'] = 'Postal Code:';
$mod_strings['LBL_BILLING_ADDRESS_CITY'] = 'City:';
$mod_strings['LBL_BILLING_ADDRESS_COUNTRY'] = 'Country:';
$mod_strings['LBL_FUNDSTRATEGY'] = 'Fund Strategy';
$mod_strings['LBL_FUNDTYPE'] = 'Fund Type';
$mod_strings['LBL_ADDITIONALINFORMATION'] = 'Additional Information';
$mod_strings['LBL_OTHERINFORMATION '] = 'Other Information ';
$mod_strings['LBL_MAPLOCATION'] = 'Location';
$mod_strings['LBL_BILLING_ADDRESS_STATE'] = 'State';
$mod_strings['LBL_PANEL_ADVANCED'] = 'Management & Fund Information';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Location';
$mod_strings['LBL_PHONE_FAX'] = 'Other Phone';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'Location';

?>
