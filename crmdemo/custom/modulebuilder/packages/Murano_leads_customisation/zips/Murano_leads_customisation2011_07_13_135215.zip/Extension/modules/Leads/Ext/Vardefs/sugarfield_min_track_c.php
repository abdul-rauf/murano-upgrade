<?php
 // created: 2011-05-19 17:11:13
$dictionary['Lead']['fields']['min_track_c']['dependency']='';

 ?>