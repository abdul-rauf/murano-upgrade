<?php
// created: 2011-02-07 10:53:05
$dictionary["Lead"]["fields"]["calls_leads_1"] = array (
  'name' => 'calls_leads_1',
  'type' => 'link',
  'relationship' => 'calls_leads_1',
  'source' => 'non-db',
  'vname' => 'LBL_CALLS_LEADS_1_FROM_CALLS_TITLE',
);
