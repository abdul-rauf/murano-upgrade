<?php
 // created: 2011-05-24 11:34:08
$dictionary['Lead']['fields']['fund_type_c']['dependency']='';

 ?>