<?php
 // created: 2011-05-19 17:10:40
$dictionary['Lead']['fields']['allocating_c']['dependency']='';

 ?>