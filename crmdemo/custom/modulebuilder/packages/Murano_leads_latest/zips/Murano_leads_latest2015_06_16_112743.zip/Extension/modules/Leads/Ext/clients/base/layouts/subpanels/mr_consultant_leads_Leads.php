<?php
// created: 2015-02-22 18:55:25
$viewdefs['Leads']['base']['layout']['subpanels']['components'][] = array (
  'label' => 'LBL_MR_CONSULTANT_LEADS_FROM_MR_CONSULTANT_TITLE',
  'context' => 
  array (
    'link' => 'mr_consultant_leads',
  ),
  'layout' => 'subpanel',
);