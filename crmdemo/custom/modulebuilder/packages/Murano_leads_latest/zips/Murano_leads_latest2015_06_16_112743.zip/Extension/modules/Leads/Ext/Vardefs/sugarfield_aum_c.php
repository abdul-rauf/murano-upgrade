<?php
 // created: 2011-06-01 17:43:26
$dictionary['Lead']['fields']['aum_c']['enforced']='false';
$dictionary['Lead']['fields']['aum_c']['dependency']='';

 ?>