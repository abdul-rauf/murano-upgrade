<?php
 // created: 2013-05-22 12:13:48
$dictionary['Lead']['fields']['fund_type_c']['dependency']='';

 ?>