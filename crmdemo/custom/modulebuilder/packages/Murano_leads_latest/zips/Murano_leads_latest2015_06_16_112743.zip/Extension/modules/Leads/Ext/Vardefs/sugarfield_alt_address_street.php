<?php
 // created: 2011-01-20 13:43:03
$dictionary['Lead']['fields']['alt_address_street']['calculated']=false;

 ?>