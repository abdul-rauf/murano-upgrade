<?php
 // created: 2014-04-14 14:31:30
$dictionary['Lead']['fields']['continent_c']['dependency']='';
$dictionary['Lead']['fields']['continent_c']['visibility_grid']='';

 ?>