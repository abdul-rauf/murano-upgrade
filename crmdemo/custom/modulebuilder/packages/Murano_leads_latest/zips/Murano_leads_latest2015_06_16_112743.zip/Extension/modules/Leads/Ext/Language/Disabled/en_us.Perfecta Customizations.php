<?php 
 // created: 2011-05-12 19:04:31
$mod_strings['LBL_LAST_NAME'] = 'Last Name:';

?>
