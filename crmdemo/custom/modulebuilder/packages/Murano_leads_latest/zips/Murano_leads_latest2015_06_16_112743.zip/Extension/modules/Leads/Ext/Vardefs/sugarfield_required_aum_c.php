<?php
 // created: 2013-01-22 11:24:37
$dictionary['Lead']['fields']['required_aum_c']['dependency']='';
$dictionary['Lead']['fields']['required_aum_c']['visibility_grid']='';

 ?>