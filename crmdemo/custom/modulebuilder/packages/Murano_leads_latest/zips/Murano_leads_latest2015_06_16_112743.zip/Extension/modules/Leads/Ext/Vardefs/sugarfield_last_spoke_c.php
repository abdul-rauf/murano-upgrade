<?php
 // created: 2014-04-14 14:19:10
$dictionary['Lead']['fields']['last_spoke_c']['enforced']='';
$dictionary['Lead']['fields']['last_spoke_c']['dependency']='';

 ?>