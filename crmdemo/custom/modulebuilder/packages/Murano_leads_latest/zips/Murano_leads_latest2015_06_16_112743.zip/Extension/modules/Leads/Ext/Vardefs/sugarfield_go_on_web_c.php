<?php
 // created: 2014-12-17 12:07:46
$dictionary['Lead']['fields']['go_on_web_c']['enforced']='';
$dictionary['Lead']['fields']['go_on_web_c']['dependency']='';

 ?>