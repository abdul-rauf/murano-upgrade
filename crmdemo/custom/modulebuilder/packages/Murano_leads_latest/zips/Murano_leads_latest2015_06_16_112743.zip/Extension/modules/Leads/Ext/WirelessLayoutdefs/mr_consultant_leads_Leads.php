<?php
 // created: 2013-01-18 09:00:48
$layout_defs["Leads"]["subpanel_setup"]['mr_consultant_leads'] = array (
  'order' => 100,
  'module' => 'mr_consultant',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_MR_CONSULTANT_LEADS_FROM_MR_CONSULTANT_TITLE',
  'get_subpanel_data' => 'mr_consultant_leads',
);
