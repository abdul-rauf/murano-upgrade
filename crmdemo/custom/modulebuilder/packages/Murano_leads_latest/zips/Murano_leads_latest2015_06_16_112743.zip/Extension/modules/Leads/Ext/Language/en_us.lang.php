<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_ALLOCATING'] = 'Allocating';
$mod_strings['LBL_ACCOUNT_DESCRIPTION'] = 'Notes';
$mod_strings['LBL_FURTHER_INFORMATION'] = 'Company Description';
$mod_strings['LBL_FUND_STRUCTURE'] = 'Fund Structure';
