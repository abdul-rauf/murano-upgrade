<?php
// created: 2013-01-18 09:00:48
$dictionary["Lead"]["fields"]["mr_consultant_leads"] = array (
  'name' => 'mr_consultant_leads',
  'type' => 'link',
  'relationship' => 'mr_consultant_leads',
  'source' => 'non-db',
  'vname' => 'LBL_MR_CONSULTANT_LEADS_FROM_MR_CONSULTANT_TITLE',
);
