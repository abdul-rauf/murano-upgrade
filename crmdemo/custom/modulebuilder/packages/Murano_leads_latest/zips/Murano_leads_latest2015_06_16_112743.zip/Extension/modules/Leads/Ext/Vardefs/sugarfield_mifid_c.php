<?php
 // created: 2014-04-14 14:18:15
$dictionary['Lead']['fields']['mifid_c']['dependency']='';
$dictionary['Lead']['fields']['mifid_c']['visibility_grid']='';

 ?>