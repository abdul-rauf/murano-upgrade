<?php
 // created: 2011-09-08 11:10:47
$dictionary['Lead']['fields']['fum_curr1_c']['dependency']='';

 ?>