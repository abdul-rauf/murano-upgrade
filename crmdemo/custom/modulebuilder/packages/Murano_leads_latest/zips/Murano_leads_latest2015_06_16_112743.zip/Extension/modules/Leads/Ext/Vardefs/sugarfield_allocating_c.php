<?php
 // created: 2015-04-13 14:38:18
$dictionary['Lead']['fields']['allocating_c']['labelValue']='Allocating';
$dictionary['Lead']['fields']['allocating_c']['dependency']='';
$dictionary['Lead']['fields']['allocating_c']['visibility_grid']='';

 ?>