<?php
 // created: 2014-05-27 11:57:13
$dictionary['Lead']['fields']['website']['calculated']=false;
$dictionary['Lead']['fields']['website']['link_target']='_blank';
$dictionary['Lead']['fields']['website']['default']='';
$dictionary['Lead']['fields']['website']['massupdate']=0;
$dictionary['Lead']['fields']['website']['comments']='URL of website for the company';
$dictionary['Lead']['fields']['website']['merge_filter']='disabled';

 ?>