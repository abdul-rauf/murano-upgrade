<?php
 // created: 2014-05-27 11:55:42
$dictionary['Lead']['fields']['req_aum_c']['enforced']='false';
$dictionary['Lead']['fields']['req_aum_c']['dependency']='';

 ?>