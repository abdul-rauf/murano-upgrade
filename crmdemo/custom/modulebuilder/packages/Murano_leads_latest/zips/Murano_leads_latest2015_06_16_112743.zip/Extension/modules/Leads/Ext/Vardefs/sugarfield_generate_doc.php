<?php
$dictionary["Lead"]["fields"]['generate_doc'] = 
    array (
      'name' => 'generate_doc',
      'vname' => 'LBL_GENERATE_DOC',
      'type' => 'varchar',
'source' =>'non-db',
      'len' => '150',
	 'comment' => 'BUTTON FOR GENERATE DOC',
	  'studio' => array('detailview'=>true),
    );
 ?>