<?php 
 // created: 2011-05-12 19:35:31
$mod_strings['LBL_SEND_QUICK_EMAIL'] = 'Enquire';

?>
