<?php
 // created: 2014-01-22 14:31:45
$dictionary['Lead']['fields']['primary_address_country']['calculated']=false;
$dictionary['Lead']['fields']['primary_address_country']['massupdate']=0;
$dictionary['Lead']['fields']['primary_address_country']['comments']='Country for primary address';
$dictionary['Lead']['fields']['primary_address_country']['merge_filter']='disabled';

 ?>