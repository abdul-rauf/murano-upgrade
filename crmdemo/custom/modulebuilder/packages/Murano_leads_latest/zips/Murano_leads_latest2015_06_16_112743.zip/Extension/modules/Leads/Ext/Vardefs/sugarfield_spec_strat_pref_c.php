<?php
 // created: 2013-05-22 12:14:26
$dictionary['Lead']['fields']['spec_strat_pref_c']['dependency']='';

 ?>