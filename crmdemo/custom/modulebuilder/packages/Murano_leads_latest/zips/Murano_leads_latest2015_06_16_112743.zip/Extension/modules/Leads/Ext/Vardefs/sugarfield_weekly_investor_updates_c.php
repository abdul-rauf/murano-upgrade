<?php
 // created: 2014-04-07 14:42:36
$dictionary['Lead']['fields']['weekly_investor_updates_c']['enforced']='';
$dictionary['Lead']['fields']['weekly_investor_updates_c']['dependency']='';
$dictionary['Lead']['fields']['weekly_investor_updates_c']['massupdate']=1;

 ?>