<?php
 // created: 2011-07-12 10:34:08
$dictionary['Lead']['fields']['primary_address_state']['massupdate']=1;


 ?>