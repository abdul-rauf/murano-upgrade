<?php
 // created: 2013-10-03 09:11:23
$dictionary['Lead']['fields']['min_track_c']['dependency']='';
$dictionary['Lead']['fields']['min_track_c']['visibility_grid']='';

 ?>