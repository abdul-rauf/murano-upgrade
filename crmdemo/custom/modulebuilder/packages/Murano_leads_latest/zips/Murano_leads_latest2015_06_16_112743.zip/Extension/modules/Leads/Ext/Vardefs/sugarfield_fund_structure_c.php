<?php
 // created: 2015-05-21 09:37:35
$dictionary['Lead']['fields']['fund_structure_c']['labelValue']='Fund Structure';
$dictionary['Lead']['fields']['fund_structure_c']['dependency']='';
$dictionary['Lead']['fields']['fund_structure_c']['visibility_grid']='';

 ?>