<?php
 // created: 2015-01-14 18:10:19
$dictionary['Lead']['fields']['con1']['massupdate']=0;
$dictionary['Lead']['fields']['con1']['options']='blank_list';
$dictionary['Lead']['fields']['con1']['comments']='The street address used for billing address';
$dictionary['Lead']['fields']['con1']['merge_filter']='disabled';
$dictionary['Lead']['fields']['con1']['calculated']=false;
$dictionary['Lead']['fields']['con1']['dependency']='';

 ?>