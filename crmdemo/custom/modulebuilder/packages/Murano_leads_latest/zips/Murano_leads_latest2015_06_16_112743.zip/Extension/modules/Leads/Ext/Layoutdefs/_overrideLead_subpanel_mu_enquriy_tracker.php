<?php
//auto-generated file DO NOT EDIT
$layout_defs['Leads']['subpanel_setup']['mu_enquriy_tracker']['override_subpanel_name'] = 'Lead_subpanel_mu_enquriy_tracker';
?>