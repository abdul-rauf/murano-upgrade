<?php
// created: 2012-12-18 14:50:26
$dictionary["Lead"]["fields"]['email1_new'] = 
    array (
      'name' => 'email1_new',
      'vname' => 'Email Address',
      'type' => 'varchar',
      'len' => '150',

       'merge_filter' => 'enabled',
	  'importable' => 'false',
    );
