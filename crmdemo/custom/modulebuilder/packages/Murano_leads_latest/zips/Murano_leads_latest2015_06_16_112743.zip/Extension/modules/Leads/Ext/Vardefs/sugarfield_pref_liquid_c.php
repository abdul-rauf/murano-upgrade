<?php
 // created: 2013-10-03 09:10:18
$dictionary['Lead']['fields']['pref_liquid_c']['dependency']='';
$dictionary['Lead']['fields']['pref_liquid_c']['visibility_grid']='';

 ?>