<?php
 // created: 2013-08-30 14:14:19
$dictionary['Lead']['fields']['consultant']['comments']='The street address used for billing address';
$dictionary['Lead']['fields']['consultant']['merge_filter']='disabled';
$dictionary['Lead']['fields']['consultant']['calculated']=false;

 ?>