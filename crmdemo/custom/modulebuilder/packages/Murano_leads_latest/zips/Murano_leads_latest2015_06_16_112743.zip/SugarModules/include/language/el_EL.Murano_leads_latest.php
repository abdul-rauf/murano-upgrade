<?php 
$app_list_strings['structure_list'] = array (
  '40_Act' => '40 Act',
  'European_Onshore' => 'European Onshore',
  'Mutual_Fund' => 'Mutual Fund',
  'Offshore' => 'Offshore',
  'UCITS' => 'UCITS',
  'US_Onshore' => 'US Onshore',
  'Other' => 'Other',
  'Managed_Account' => 'Managed Account',
  'FCP' => 'FCP',
  'QIF ' => 'QIF ',
);