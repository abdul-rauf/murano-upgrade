<?php


class get_email1{

function get_email_save(&$bean,$event,$arguments){

$bean->email1_new =$bean->email1;

}


}