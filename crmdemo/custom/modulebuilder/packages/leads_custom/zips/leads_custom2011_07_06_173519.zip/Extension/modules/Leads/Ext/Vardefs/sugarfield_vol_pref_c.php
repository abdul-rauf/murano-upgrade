<?php
 // created: 2011-05-18 12:38:55
$dictionary['Lead']['fields']['vol_pref_c']['dependency']='';

 ?>