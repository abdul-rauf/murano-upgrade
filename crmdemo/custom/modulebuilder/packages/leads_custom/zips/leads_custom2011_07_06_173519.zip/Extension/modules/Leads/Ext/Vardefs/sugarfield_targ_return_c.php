<?php
 // created: 2011-05-25 14:57:09
$dictionary['Lead']['fields']['targ_return_c']['enforced']='false';
$dictionary['Lead']['fields']['targ_return_c']['dependency']='';

 ?>