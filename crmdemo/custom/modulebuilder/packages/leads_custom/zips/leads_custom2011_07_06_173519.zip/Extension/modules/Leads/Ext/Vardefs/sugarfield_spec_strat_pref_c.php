<?php
 // created: 2011-06-01 17:45:22
$dictionary['Lead']['fields']['spec_strat_pref_c']['dependency']='';

 ?>