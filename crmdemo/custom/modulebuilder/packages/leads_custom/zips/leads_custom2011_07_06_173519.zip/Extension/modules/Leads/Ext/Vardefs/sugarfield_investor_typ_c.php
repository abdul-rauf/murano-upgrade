<?php
 // created: 2011-05-24 15:53:50
$dictionary['Lead']['fields']['investor_typ_c']['dependency']='';

 ?>