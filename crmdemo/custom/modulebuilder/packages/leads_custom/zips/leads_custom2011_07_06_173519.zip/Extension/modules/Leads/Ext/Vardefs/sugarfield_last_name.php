<?php
 // created: 2011-02-16 11:07:27
$dictionary['Lead']['fields']['last_name']['required']=false;
$dictionary['Lead']['fields']['last_name']['calculated']=false;
$dictionary['Lead']['fields']['last_name']['importable']='true';

 ?>