<?php
 // created: 2011-06-28 14:37:34
$dictionary['Lead']['fields']['avg_time_monitored_c']['enforced']='false';
$dictionary['Lead']['fields']['avg_time_monitored_c']['dependency']='';

 ?>