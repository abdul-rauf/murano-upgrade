<?php
 // created: 2011-05-18 11:54:23
$dictionary['Lead']['fields']['peralloc_hf_c']['enforced']='false';
$dictionary['Lead']['fields']['peralloc_hf_c']['dependency']='';

 ?>