<?php
 // created: 2011-05-19 17:10:57
$dictionary['Lead']['fields']['alloc_fohfs_c']['dependency']='';

 ?>