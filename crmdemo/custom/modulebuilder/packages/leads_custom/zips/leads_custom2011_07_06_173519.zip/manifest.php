    <?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Professional Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-professional-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2011 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/


    $manifest = array (
         'acceptable_sugar_versions' => 
          array (
            '6.2.0RC1'
          ),
          'acceptable_sugar_flavors' =>
          array(
            'PRO'
          ),
          'readme'=>'',
          'key'=>'',
          'author' => '52nd',
          'description' => 'Leads Customisation',
          'icon' => '',
          'is_uninstallable' => true,
          'name' => 'leads_custom',
          'published_date' => '2011-07-06 16:35:17',
          'type' => 'module',
          'version' => '1309970119',
          'remove_tables' => 'prompt',
          );
$installdefs = array (
  'id' => 'leads_custom',
  'language' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/bg_BG.leads_custom.php',
      'to_module' => 'application',
      'language' => 'bg_BG',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/cs_CZ.leads_custom.php',
      'to_module' => 'application',
      'language' => 'cs_CZ',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/da_DK.leads_custom.php',
      'to_module' => 'application',
      'language' => 'da_DK',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/de_DE.leads_custom.php',
      'to_module' => 'application',
      'language' => 'de_DE',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/en_us.leads_custom.php',
      'to_module' => 'application',
      'language' => 'en_us',
    ),
    5 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/es_ES.leads_custom.php',
      'to_module' => 'application',
      'language' => 'es_ES',
    ),
    6 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/et_EE.leads_custom.php',
      'to_module' => 'application',
      'language' => 'et_EE',
    ),
    7 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/fr_FR.leads_custom.php',
      'to_module' => 'application',
      'language' => 'fr_FR',
    ),
    8 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/he_IL.leads_custom.php',
      'to_module' => 'application',
      'language' => 'he_IL',
    ),
    9 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/hu_HU.leads_custom.php',
      'to_module' => 'application',
      'language' => 'hu_HU',
    ),
    10 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/it_it.leads_custom.php',
      'to_module' => 'application',
      'language' => 'it_it',
    ),
    11 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/ja_JP.leads_custom.php',
      'to_module' => 'application',
      'language' => 'ja_JP',
    ),
    12 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/lt_LT.leads_custom.php',
      'to_module' => 'application',
      'language' => 'lt_LT',
    ),
    13 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/nb_NO.leads_custom.php',
      'to_module' => 'application',
      'language' => 'nb_NO',
    ),
    14 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/nl_NL.leads_custom.php',
      'to_module' => 'application',
      'language' => 'nl_NL',
    ),
    15 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/pl_PL.leads_custom.php',
      'to_module' => 'application',
      'language' => 'pl_PL',
    ),
    16 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/pt_PT.leads_custom.php',
      'to_module' => 'application',
      'language' => 'pt_PT',
    ),
    17 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/ro_RO.leads_custom.php',
      'to_module' => 'application',
      'language' => 'ro_RO',
    ),
    18 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/ru_RU.leads_custom.php',
      'to_module' => 'application',
      'language' => 'ru_RU',
    ),
    19 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/sv_SE.leads_custom.php',
      'to_module' => 'application',
      'language' => 'sv_SE',
    ),
    20 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/tr_TR.leads_custom.php',
      'to_module' => 'application',
      'language' => 'tr_TR',
    ),
    21 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/zh_CN.leads_custom.php',
      'to_module' => 'application',
      'language' => 'zh_CN',
    ),
    22 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/language/en_us.lang.php',
      'to_module' => 'Leads',
      'language' => 'en_us',
    ),
  ),
  'custom_fields' => 
  array (
    'Leadsfsa_c' => 
    array (
      'id' => 'Leadsfsa_c',
      'name' => 'fsa_c',
      'label' => 'LBL_FSA',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => 'YES',
      'date_modified' => '2011-05-12 18:37:33',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'FSA_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsnotes_c' => 
    array (
      'id' => 'Leadsnotes_c',
      'name' => 'notes_c',
      'label' => 'LBL_NOTES',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'text',
      'max_size' => NULL,
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-12 18:37:33',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => '15',
      'ext3' => '80',
      'ext4' => NULL,
    ),
    'Leadsnewslinks_c' => 
    array (
      'id' => 'Leadsnewslinks_c',
      'name' => 'newslinks_c',
      'label' => 'LBL_NEWSLINKS',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'text',
      'max_size' => NULL,
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-12 18:37:33',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => '15',
      'ext3' => '80',
      'ext4' => NULL,
    ),
    'Leadsfundname_c' => 
    array (
      'id' => 'Leadsfundname_c',
      'name' => 'fundname_c',
      'label' => 'LBL_FUNDNAME',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-12 18:37:33',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsfund_manager_c' => 
    array (
      'id' => 'Leadsfund_manager_c',
      'name' => 'fund_manager_c',
      'label' => 'LBL_FUND_MANAGER',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-12 18:37:33',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsaum_c' => 
    array (
      'id' => 'Leadsaum_c',
      'name' => 'aum_c',
      'label' => 'LBL_AUM',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-06-01 16:43:26',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsfund_type_c' => 
    array (
      'id' => 'Leadsfund_type_c',
      'name' => 'fund_type_c',
      'label' => 'LBL_FUND_TYPE',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'multienum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => '^^',
      'date_modified' => '2011-05-24 10:34:08',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'FundType_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => 'a:1:{s:10:&quot;dependency&quot;;s:0:&quot;&quot;;}',
    ),
    'Leadsinvestment_geography_c' => 
    array (
      'id' => 'Leadsinvestment_geography_c',
      'name' => 'investment_geography_c',
      'label' => 'LBL_INVESTMENT_GEOGRAPHY',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'multienum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => '^^',
      'date_modified' => '2011-05-12 18:37:33',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'InvestmentGeog_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => '^^',
    ),
    'Leadsownership_c' => 
    array (
      'id' => 'Leadsownership_c',
      'name' => 'ownership_c',
      'label' => 'LBL_OWNERSHIP',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-12 18:37:33',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsfurther_information_c' => 
    array (
      'id' => 'Leadsfurther_information_c',
      'name' => 'further_information_c',
      'label' => 'LBL_FURTHER_INFORMATION',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'text',
      'max_size' => NULL,
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-12 18:37:33',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => '10',
      'ext3' => '80',
      'ext4' => NULL,
    ),
    'Leadsalternatename_c' => 
    array (
      'id' => 'Leadsalternatename_c',
      'name' => 'alternatename_c',
      'label' => 'LBL_ALTERNATENAME',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-12 18:37:33',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsalternatelastname_c' => 
    array (
      'id' => 'Leadsalternatelastname_c',
      'name' => 'alternatelastname_c',
      'label' => 'LBL_ALTERNATELASTNAME',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-12 18:37:33',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsalternatetitle_c' => 
    array (
      'id' => 'Leadsalternatetitle_c',
      'name' => 'alternatetitle_c',
      'label' => 'LBL_ALTERNATETITLE',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-12 18:37:33',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsperalloc_hf_c' => 
    array (
      'id' => 'Leadsperalloc_hf_c',
      'name' => 'peralloc_hf_c',
      'label' => 'LBL_PERALLOC_HF',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-18 10:54:23',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsfum_curr1_c' => 
    array (
      'id' => 'Leadsfum_curr1_c',
      'name' => 'fum_curr1_c',
      'label' => 'LBL_FUM_CURR1',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => 'Unknown',
      'date_modified' => '2011-05-19 16:10:16',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'FuMCurr_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => 's:0:&quot;&quot;;',
    ),
    'Leadstyp_invest_c' => 
    array (
      'id' => 'Leadstyp_invest_c',
      'name' => 'typ_invest_c',
      'label' => 'LBL_TYP_INVEST',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-18 10:53:38',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsloc_pref_c' => 
    array (
      'id' => 'Leadsloc_pref_c',
      'name' => 'loc_pref_c',
      'label' => 'LBL_LOC_PREF',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'multienum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-18 11:14:20',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'loc_pref_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => 'a:1:{s:10:&quot;dependency&quot;;s:0:&quot;&quot;;}',
    ),
    'Leadsvol_pref_c' => 
    array (
      'id' => 'Leadsvol_pref_c',
      'name' => 'vol_pref_c',
      'label' => 'LBL_VOL_PREF',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'multienum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-18 11:38:54',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'vol_pref_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => 'a:1:{s:10:&quot;dependency&quot;;s:0:&quot;&quot;;}',
    ),
    'Leadsallocating_c' => 
    array (
      'id' => 'Leadsallocating_c',
      'name' => 'allocating_c',
      'label' => 'LBL_ALLOCATING',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => 'Unknown',
      'date_modified' => '2011-05-19 16:10:36',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'allocating_c_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => 's:0:&quot;&quot;;',
    ),
    'Leadstarg_return_c' => 
    array (
      'id' => 'Leadstarg_return_c',
      'name' => 'targ_return_c',
      'label' => 'LBL_TARG_RETURN',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-25 13:57:05',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsreq_aum_c' => 
    array (
      'id' => 'Leadsreq_aum_c',
      'name' => 'req_aum_c',
      'label' => 'LBL_REQ_AUM',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-18 12:51:40',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsalloc_fohfs_c' => 
    array (
      'id' => 'Leadsalloc_fohfs_c',
      'name' => 'alloc_fohfs_c',
      'label' => 'LBL_ALLOC_FOHFS',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => 'Unknown',
      'date_modified' => '2011-05-19 16:10:56',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'allocating_c_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => 's:0:&quot;&quot;;',
    ),
    'Leadsmin_track_c' => 
    array (
      'id' => 'Leadsmin_track_c',
      'name' => 'min_track_c',
      'label' => 'LBL_MIN_TRACK',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => 'Unknown',
      'date_modified' => '2011-05-19 16:11:13',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'min_track_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => 's:0:&quot;&quot;;',
    ),
    'Leadspref_liquid_c' => 
    array (
      'id' => 'Leadspref_liquid_c',
      'name' => 'pref_liquid_c',
      'label' => 'LBL_PREF_LIQUID',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => 'Unknown',
      'date_modified' => '2011-05-19 16:12:05',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'pref_liquid_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => 's:0:&quot;&quot;;',
    ),
    'Leadstypcom_size_c' => 
    array (
      'id' => 'Leadstypcom_size_c',
      'name' => 'typcom_size_c',
      'label' => 'LBL_TYPCOM_SIZE',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-18 12:58:06',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsspec_strat_pref_c' => 
    array (
      'id' => 'Leadsspec_strat_pref_c',
      'name' => 'spec_strat_pref_c',
      'label' => 'LBL_SPEC_STRAT_PREF',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'multienum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-06-01 16:45:22',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'spec_strat_pref_c_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => 'a:1:{s:10:&quot;dependency&quot;;s:0:&quot;&quot;;}',
    ),
    'Leadsinvestor_typ_c' => 
    array (
      'id' => 'Leadsinvestor_typ_c',
      'name' => 'investor_typ_c',
      'label' => 'LBL_INVESTOR_TYP',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'multienum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-05-24 14:53:49',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'fundstrategy_c_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => 'a:1:{s:10:&quot;dependency&quot;;s:0:&quot;&quot;;}',
    ),
    'Leadsavg_time_monitored_c' => 
    array (
      'id' => 'Leadsavg_time_monitored_c',
      'name' => 'avg_time_monitored_c',
      'label' => 'LBL_AVG_TIME_MONITORED',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-06-28 13:37:33',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
  ),
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/convertdefs.php',
      'to' => 'custom/modules/Leads/metadata/convertdefs.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/convertdefs.php',
      'to' => 'custom/working/modules/Leads/metadata/convertdefs.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/detailviewdefs.php',
      'to' => 'custom/modules/Leads/metadata/detailviewdefs.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/detailviewdefs.php',
      'to' => 'custom/working/modules/Leads/metadata/detailviewdefs.php',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/editviewdefs.php',
      'to' => 'custom/modules/Leads/metadata/editviewdefs.php',
    ),
    5 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/editviewdefs.php',
      'to' => 'custom/working/modules/Leads/metadata/editviewdefs.php',
    ),
    6 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/listviewdefs.php',
      'to' => 'custom/modules/Leads/metadata/listviewdefs.php',
    ),
    7 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/popupdefs.php',
      'to' => 'custom/modules/Leads/metadata/popupdefs.php',
    ),
    8 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/popupdefs.php',
      'to' => 'custom/working/modules/Leads/metadata/popupdefs.php',
    ),
    9 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/quickcreatedefs.php',
      'to' => 'custom/modules/Leads/metadata/quickcreatedefs.php',
    ),
    10 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/quickcreatedefs.php',
      'to' => 'custom/working/modules/Leads/metadata/quickcreatedefs.php',
    ),
    11 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/searchdefs.php',
      'to' => 'custom/modules/Leads/metadata/searchdefs.php',
    ),
    12 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/searchdefs.php',
      'to' => 'custom/working/modules/Leads/metadata/searchdefs.php',
    ),
    13 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/wireless.listviewdefs.php',
      'to' => 'custom/modules/Leads/metadata/wireless.listviewdefs.php',
    ),
    14 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/wireless.listviewdefs.php',
      'to' => 'custom/working/modules/Leads/metadata/wireless.listviewdefs.php',
    ),
    15 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/bg_BG.Perfecta Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/bg_BG.Perfecta Leads.php',
    ),
    16 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/bg_BG.customaccounts_leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/bg_BG.customaccounts_leads.php',
    ),
    17 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/bg_BG.customaccounts_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/bg_BG.customaccounts_leads_1.php',
    ),
    18 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/bg_BG.customaccounts_leads_2.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/bg_BG.customaccounts_leads_2.php',
    ),
    19 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/bg_BG.customcalls_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/bg_BG.customcalls_leads_1.php',
    ),
    20 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/bg_BG.customleads_documents_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/bg_BG.customleads_documents_1.php',
    ),
    21 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/da_DK.Perfecta Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/da_DK.Perfecta Leads.php',
    ),
    22 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/da_DK.customaccounts_leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/da_DK.customaccounts_leads.php',
    ),
    23 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/da_DK.customaccounts_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/da_DK.customaccounts_leads_1.php',
    ),
    24 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/da_DK.customaccounts_leads_2.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/da_DK.customaccounts_leads_2.php',
    ),
    25 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/da_DK.customcalls_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/da_DK.customcalls_leads_1.php',
    ),
    26 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/da_DK.customleads_documents_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/da_DK.customleads_documents_1.php',
    ),
    27 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/de_DE.Perfecta Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/de_DE.Perfecta Leads.php',
    ),
    28 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/de_DE.customaccounts_leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/de_DE.customaccounts_leads.php',
    ),
    29 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/de_DE.customaccounts_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/de_DE.customaccounts_leads_1.php',
    ),
    30 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/de_DE.customaccounts_leads_2.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/de_DE.customaccounts_leads_2.php',
    ),
    31 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/de_DE.customcalls_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/de_DE.customcalls_leads_1.php',
    ),
    32 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/de_DE.customleads_documents_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/de_DE.customleads_documents_1.php',
    ),
    33 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/en_us.Murano2.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/en_us.Murano2.php',
    ),
    34 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/en_us.Perfecta Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/en_us.Perfecta Leads.php',
    ),
    35 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/en_us.Perfecta1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/en_us.Perfecta1.php',
    ),
    36 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/en_us.customaccounts_leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/en_us.customaccounts_leads.php',
    ),
    37 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/en_us.customaccounts_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/en_us.customaccounts_leads_1.php',
    ),
    38 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/en_us.customaccounts_leads_2.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/en_us.customaccounts_leads_2.php',
    ),
    39 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/en_us.customcalls_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/en_us.customcalls_leads_1.php',
    ),
    40 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/en_us.customleads_documents_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/en_us.customleads_documents_1.php',
    ),
    41 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/es_ES.Perfecta Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/es_ES.Perfecta Leads.php',
    ),
    42 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/es_ES.customaccounts_leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/es_ES.customaccounts_leads.php',
    ),
    43 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/es_ES.customaccounts_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/es_ES.customaccounts_leads_1.php',
    ),
    44 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/es_ES.customaccounts_leads_2.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/es_ES.customaccounts_leads_2.php',
    ),
    45 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/es_ES.customcalls_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/es_ES.customcalls_leads_1.php',
    ),
    46 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/es_ES.customleads_documents_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/es_ES.customleads_documents_1.php',
    ),
    47 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/fr_FR.Perfecta Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/fr_FR.Perfecta Leads.php',
    ),
    48 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/fr_FR.customaccounts_leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/fr_FR.customaccounts_leads.php',
    ),
    49 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/fr_FR.customaccounts_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/fr_FR.customaccounts_leads_1.php',
    ),
    50 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/fr_FR.customaccounts_leads_2.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/fr_FR.customaccounts_leads_2.php',
    ),
    51 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/fr_FR.customcalls_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/fr_FR.customcalls_leads_1.php',
    ),
    52 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/fr_FR.customleads_documents_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/fr_FR.customleads_documents_1.php',
    ),
    53 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/hu_HU.Perfecta Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/hu_HU.Perfecta Leads.php',
    ),
    54 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/hu_HU.customaccounts_leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/hu_HU.customaccounts_leads.php',
    ),
    55 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/hu_HU.customaccounts_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/hu_HU.customaccounts_leads_1.php',
    ),
    56 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/hu_HU.customaccounts_leads_2.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/hu_HU.customaccounts_leads_2.php',
    ),
    57 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/hu_HU.customcalls_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/hu_HU.customcalls_leads_1.php',
    ),
    58 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/hu_HU.customleads_documents_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/hu_HU.customleads_documents_1.php',
    ),
    59 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/it_it.Perfecta Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/it_it.Perfecta Leads.php',
    ),
    60 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/it_it.customaccounts_leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/it_it.customaccounts_leads.php',
    ),
    61 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/it_it.customaccounts_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/it_it.customaccounts_leads_1.php',
    ),
    62 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/it_it.customaccounts_leads_2.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/it_it.customaccounts_leads_2.php',
    ),
    63 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/it_it.customcalls_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/it_it.customcalls_leads_1.php',
    ),
    64 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/it_it.customleads_documents_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/it_it.customleads_documents_1.php',
    ),
    65 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ja_JP.Perfecta Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ja_JP.Perfecta Leads.php',
    ),
    66 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ja_JP.customaccounts_leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ja_JP.customaccounts_leads.php',
    ),
    67 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ja_JP.customaccounts_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ja_JP.customaccounts_leads_1.php',
    ),
    68 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ja_JP.customaccounts_leads_2.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ja_JP.customaccounts_leads_2.php',
    ),
    69 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ja_JP.customcalls_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ja_JP.customcalls_leads_1.php',
    ),
    70 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ja_JP.customleads_documents_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ja_JP.customleads_documents_1.php',
    ),
    71 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/nl_NL.Perfecta Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/nl_NL.Perfecta Leads.php',
    ),
    72 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/nl_NL.customaccounts_leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/nl_NL.customaccounts_leads.php',
    ),
    73 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/nl_NL.customaccounts_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/nl_NL.customaccounts_leads_1.php',
    ),
    74 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/nl_NL.customaccounts_leads_2.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/nl_NL.customaccounts_leads_2.php',
    ),
    75 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/nl_NL.customcalls_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/nl_NL.customcalls_leads_1.php',
    ),
    76 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/nl_NL.customleads_documents_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/nl_NL.customleads_documents_1.php',
    ),
    77 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/pt_PT.Perfecta Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/pt_PT.Perfecta Leads.php',
    ),
    78 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/pt_PT.customaccounts_leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/pt_PT.customaccounts_leads.php',
    ),
    79 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/pt_PT.customaccounts_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/pt_PT.customaccounts_leads_1.php',
    ),
    80 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/pt_PT.customaccounts_leads_2.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/pt_PT.customaccounts_leads_2.php',
    ),
    81 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/pt_PT.customcalls_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/pt_PT.customcalls_leads_1.php',
    ),
    82 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/pt_PT.customleads_documents_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/pt_PT.customleads_documents_1.php',
    ),
    83 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ro_RO.Perfecta Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ro_RO.Perfecta Leads.php',
    ),
    84 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ro_RO.customaccounts_leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ro_RO.customaccounts_leads.php',
    ),
    85 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ro_RO.customaccounts_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ro_RO.customaccounts_leads_1.php',
    ),
    86 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ro_RO.customaccounts_leads_2.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ro_RO.customaccounts_leads_2.php',
    ),
    87 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ro_RO.customcalls_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ro_RO.customcalls_leads_1.php',
    ),
    88 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ro_RO.customleads_documents_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ro_RO.customleads_documents_1.php',
    ),
    89 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ru_RU.Perfecta Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ru_RU.Perfecta Leads.php',
    ),
    90 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ru_RU.customaccounts_leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ru_RU.customaccounts_leads.php',
    ),
    91 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ru_RU.customaccounts_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ru_RU.customaccounts_leads_1.php',
    ),
    92 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ru_RU.customaccounts_leads_2.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ru_RU.customaccounts_leads_2.php',
    ),
    93 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ru_RU.customcalls_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ru_RU.customcalls_leads_1.php',
    ),
    94 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/ru_RU.customleads_documents_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/ru_RU.customleads_documents_1.php',
    ),
    95 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/zh_CN.Perfecta Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/zh_CN.Perfecta Leads.php',
    ),
    96 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/zh_CN.customaccounts_leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/zh_CN.customaccounts_leads.php',
    ),
    97 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/zh_CN.customaccounts_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/zh_CN.customaccounts_leads_1.php',
    ),
    98 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/zh_CN.customaccounts_leads_2.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/zh_CN.customaccounts_leads_2.php',
    ),
    99 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/zh_CN.customcalls_leads_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/zh_CN.customcalls_leads_1.php',
    ),
    100 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/zh_CN.customleads_documents_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/zh_CN.customleads_documents_1.php',
    ),
    101 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Layoutdefs/calls_leads_1_Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Layoutdefs/calls_leads_1_Leads.php',
    ),
    102 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Layoutdefs/calls_leads_Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Layoutdefs/calls_leads_Leads.php',
    ),
    103 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Layoutdefs/leads_documents_2_Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Layoutdefs/leads_documents_2_Leads.php',
    ),
    104 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/accounts_leads_1_Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/accounts_leads_1_Leads.php',
    ),
    105 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/accounts_leads_2_Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/accounts_leads_2_Leads.php',
    ),
    106 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/accounts_leads_Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/accounts_leads_Leads.php',
    ),
    107 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/calls_leads_1_Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/calls_leads_1_Leads.php',
    ),
    108 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/calls_leads_Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/calls_leads_Leads.php',
    ),
    109 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/leads_documents_1_Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/leads_documents_1_Leads.php',
    ),
    110 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/leads_documents_2_Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/leads_documents_2_Leads.php',
    ),
    111 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_account_description.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_account_description.php',
    ),
    112 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_account_name.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_account_name.php',
    ),
    113 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_alloc_fohfs_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_alloc_fohfs_c.php',
    ),
    114 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_allocating_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_allocating_c.php',
    ),
    115 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_alt_address_street.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_alt_address_street.php',
    ),
    116 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_alternatelastname_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_alternatelastname_c.php',
    ),
    117 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_alternatename_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_alternatename_c.php',
    ),
    118 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_alternatetitle_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_alternatetitle_c.php',
    ),
    119 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_aum_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_aum_c.php',
    ),
    120 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_avg_time_monitored_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_avg_time_monitored_c.php',
    ),
    121 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_description.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_description.php',
    ),
    122 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_fsa_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_fsa_c.php',
    ),
    123 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_fum_curr1_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_fum_curr1_c.php',
    ),
    124 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_fund_manager_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_fund_manager_c.php',
    ),
    125 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_fund_type_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_fund_type_c.php',
    ),
    126 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_fundname_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_fundname_c.php',
    ),
    127 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_further_information_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_further_information_c.php',
    ),
    128 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_investment_geography_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_investment_geography_c.php',
    ),
    129 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_investor_typ_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_investor_typ_c.php',
    ),
    130 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_last_name.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_last_name.php',
    ),
    131 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_loc_pref_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_loc_pref_c.php',
    ),
    132 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_min_track_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_min_track_c.php',
    ),
    133 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_newslinks_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_newslinks_c.php',
    ),
    134 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_notes_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_notes_c.php',
    ),
    135 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_ownership_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_ownership_c.php',
    ),
    136 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_peralloc_hf_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_peralloc_hf_c.php',
    ),
    137 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_pref_liquid_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_pref_liquid_c.php',
    ),
    138 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_req_aum_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_req_aum_c.php',
    ),
    139 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_spec_strat_pref_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_spec_strat_pref_c.php',
    ),
    140 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_targ_return_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_targ_return_c.php',
    ),
    141 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_typ_invest_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_typ_invest_c.php',
    ),
    142 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_typcom_size_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_typcom_size_c.php',
    ),
    143 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_vol_pref_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_vol_pref_c.php',
    ),
  ),
);