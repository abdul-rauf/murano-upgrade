<?php
// created: 2010-12-14 16:10:03
$dictionary["Document"]["fields"]["opportunities_documents"] = array (
  'name' => 'opportunities_documents',
  'type' => 'link',
  'relationship' => 'opportunities_documents',
  'source' => 'non-db',
  'vname' => 'LBL_OPPORTUNITIES_DOCUMENTS_FROM_OPPORTUNITIES_TITLE',
);
