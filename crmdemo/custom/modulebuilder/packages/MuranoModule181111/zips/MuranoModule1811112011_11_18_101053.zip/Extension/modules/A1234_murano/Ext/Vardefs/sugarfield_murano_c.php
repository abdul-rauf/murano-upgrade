<?php
 // created: 2011-06-16 10:30:50
$dictionary['A1234_murano']['fields']['murano_c']['dependency']='';

 ?>