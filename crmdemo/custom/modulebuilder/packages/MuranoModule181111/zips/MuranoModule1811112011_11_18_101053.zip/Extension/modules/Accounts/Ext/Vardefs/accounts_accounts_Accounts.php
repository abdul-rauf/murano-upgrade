<?php
// created: 2011-02-04 10:45:38
$dictionary["Account"]["fields"]["accounts_accounts"] = array (
  'name' => 'accounts_accounts',
  'type' => 'link',
  'relationship' => 'accounts_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_ACCOUNTS_ACCOUNTS_FROM_ACCOUNTS_L_TITLE',
);
$dictionary["Account"]["fields"]["accounts_accounts"] = array (
  'name' => 'accounts_accounts',
  'type' => 'link',
  'relationship' => 'accounts_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_ACCOUNTS_ACCOUNTS_FROM_ACCOUNTS_R_TITLE',
);
