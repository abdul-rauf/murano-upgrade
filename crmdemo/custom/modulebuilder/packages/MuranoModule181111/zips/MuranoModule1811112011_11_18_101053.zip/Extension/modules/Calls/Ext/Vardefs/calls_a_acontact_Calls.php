<?php
// created: 2011-02-17 12:45:07
$dictionary["Call"]["fields"]["calls_a_acontact"] = array (
  'name' => 'calls_a_acontact',
  'type' => 'link',
  'relationship' => 'calls_a_acontact',
  'source' => 'non-db',
  'vname' => 'LBL_CALLS_A_ACONTACT_FROM_A_ACONTACT_TITLE',
);
