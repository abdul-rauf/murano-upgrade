<?php
 // created: 2011-09-08 11:12:05
$dictionary['Lead']['fields']['fund_type_c']['dependency']='';

 ?>