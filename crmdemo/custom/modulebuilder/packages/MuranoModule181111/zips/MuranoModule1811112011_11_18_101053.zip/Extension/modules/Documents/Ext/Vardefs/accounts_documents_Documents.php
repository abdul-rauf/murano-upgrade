<?php
// created: 2010-12-14 16:08:03
$dictionary["Document"]["fields"]["accounts_documents"] = array (
  'name' => 'accounts_documents',
  'type' => 'link',
  'relationship' => 'accounts_documents',
  'source' => 'non-db',
  'vname' => 'LBL_ACCOUNTS_DOCUMENTS_FROM_ACCOUNTS_TITLE',
);
