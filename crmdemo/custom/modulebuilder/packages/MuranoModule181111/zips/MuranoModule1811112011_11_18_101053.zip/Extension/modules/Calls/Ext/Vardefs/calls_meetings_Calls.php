<?php
// created: 2011-02-17 12:24:34
$dictionary["Call"]["fields"]["calls_meetings"] = array (
  'name' => 'calls_meetings',
  'type' => 'link',
  'relationship' => 'calls_meetings',
  'source' => 'non-db',
  'vname' => 'LBL_CALLS_MEETINGS_FROM_MEETINGS_TITLE',
);
