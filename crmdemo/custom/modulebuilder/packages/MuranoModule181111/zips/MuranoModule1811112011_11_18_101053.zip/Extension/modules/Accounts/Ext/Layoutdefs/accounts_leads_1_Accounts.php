<?php
// created: 2011-02-04 10:45:29
$layout_defs["Accounts"]["subpanel_setup"]["accounts_leads_1"] = array (
  'order' => 100,
  'module' => 'Leads',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ACCOUNTS_LEADS_1_FROM_LEADS_TITLE',
  'get_subpanel_data' => 'accounts_leads_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
