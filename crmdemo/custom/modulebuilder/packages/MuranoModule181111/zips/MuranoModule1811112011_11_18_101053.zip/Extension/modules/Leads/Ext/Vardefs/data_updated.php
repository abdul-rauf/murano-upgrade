<?php
 // created: 2011-07-12 10:34:08
$dictionary['Lead']['fields']['data_updated']=array(
  'name' => 'data_updated',
      'vname' => 'Worked',
      'type' => 'bool',
      'default' => '0',
     'massupdate' => true,
	   'required' => false,
      'studio' => true,
      'comment' => 'An indicator of whether contact can be called',
);

 ?>