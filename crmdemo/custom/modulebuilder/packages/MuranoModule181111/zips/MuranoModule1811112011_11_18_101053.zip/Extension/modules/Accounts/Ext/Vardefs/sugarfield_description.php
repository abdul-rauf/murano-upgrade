<?php
 // created: 2011-01-20 14:28:10
$dictionary['Account']['fields']['description']['calculated']=false;
$dictionary['Account']['fields']['description']['rows']='20';

 ?>