<?php 
 // created: 2011-11-18 10:10:38
$mod_strings['LBL_MURANO'] = 'murano';

?>
