function addToWorked(item,module,record){

				if(item.className=='on'){
					item.className='off';
					item.title='not worked';
				w=0;
				}
				else{
					item.className='on';
					w =1;
					item.title='worked';
				}
var url = 'SugarWorked.php?worked_id='+record+'&worked='+w;
YAHOO.util.Connect.asyncRequest('POST',url,false,false);
}

