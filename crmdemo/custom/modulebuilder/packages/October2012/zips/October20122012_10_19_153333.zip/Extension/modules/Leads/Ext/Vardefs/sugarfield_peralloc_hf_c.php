<?php
 // created: 2012-02-09 12:05:43
$dictionary['Lead']['fields']['peralloc_hf_c']['enforced']='false';
$dictionary['Lead']['fields']['peralloc_hf_c']['dependency']='';

 ?>