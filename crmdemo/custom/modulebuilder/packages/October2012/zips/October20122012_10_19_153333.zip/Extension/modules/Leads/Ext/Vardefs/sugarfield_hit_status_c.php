<?php
 // created: 2012-03-05 14:58:09
$dictionary['Lead']['fields']['hit_status_c']['dependency']='';

 ?>