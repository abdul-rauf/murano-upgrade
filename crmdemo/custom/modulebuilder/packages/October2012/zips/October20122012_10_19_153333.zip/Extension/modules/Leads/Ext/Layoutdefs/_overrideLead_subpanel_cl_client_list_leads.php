<?php
//auto-generated file DO NOT EDIT
$layout_defs['Leads']['subpanel_setup']['cl_client_list_leads']['override_subpanel_name'] = 'Lead_subpanel_cl_client_list_leads';
?>