<?php
 // created: 2011-01-20 14:15:31
$dictionary['Lead']['fields']['account_description']['calculated']=false;
$dictionary['Lead']['fields']['account_description']['rows']='10';
$dictionary['Lead']['fields']['account_description']['cols']='80';

 ?>