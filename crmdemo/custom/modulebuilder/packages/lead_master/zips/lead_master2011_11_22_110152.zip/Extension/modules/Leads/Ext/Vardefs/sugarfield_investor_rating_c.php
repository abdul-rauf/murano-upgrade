<?php
 // created: 2011-08-04 10:01:29
$dictionary['Lead']['fields']['investor_rating_c']['dependency']='';

 ?>