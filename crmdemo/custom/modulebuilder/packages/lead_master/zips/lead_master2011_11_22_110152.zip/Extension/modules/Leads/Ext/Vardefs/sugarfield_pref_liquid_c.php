<?php
 // created: 2011-09-08 11:15:17
$dictionary['Lead']['fields']['pref_liquid_c']['dependency']='';

 ?>