<?php
 // created: 2011-07-12 10:14:50
$dictionary['Lead']['fields']['avg_time_monitored_c']['enforced']='false';
$dictionary['Lead']['fields']['avg_time_monitored_c']['dependency']='';

 ?>