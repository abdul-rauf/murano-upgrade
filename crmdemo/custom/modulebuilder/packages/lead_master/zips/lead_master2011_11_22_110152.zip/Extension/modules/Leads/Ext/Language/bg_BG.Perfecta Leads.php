<?php 
 // created: 2011-02-09 16:41:50
$mod_strings['LNK_NEW_DOCUMENT'] = 'Create Document';
$mod_strings['LNK_SELECT_DOCUMENTS'] = ' <b>OR</b> Select Document';
$mod_strings['LNK_SELECT_LEADS'] = ' <b>OR</b> Select Lead';
$mod_strings['LNK_NEW_MC_MURANO_COMPANY'] = 'Create mc_Murano_Company';
$mod_strings['LNK_SELECT_MC_MURANO_COMPANY'] = ' <b>OR</b> Select mc_Murano_Company';

?>
