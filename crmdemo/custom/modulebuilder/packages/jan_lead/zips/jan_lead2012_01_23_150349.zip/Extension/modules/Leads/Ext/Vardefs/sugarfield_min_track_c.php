<?php
 // created: 2011-09-08 11:14:28
$dictionary['Lead']['fields']['min_track_c']['dependency']='';

 ?>