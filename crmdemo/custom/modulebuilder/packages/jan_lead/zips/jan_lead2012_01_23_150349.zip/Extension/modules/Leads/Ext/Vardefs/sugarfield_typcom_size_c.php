<?php
 // created: 2011-05-18 13:58:06
$dictionary['Lead']['fields']['typcom_size_c']['enforced']='false';
$dictionary['Lead']['fields']['typcom_size_c']['dependency']='';

 ?>