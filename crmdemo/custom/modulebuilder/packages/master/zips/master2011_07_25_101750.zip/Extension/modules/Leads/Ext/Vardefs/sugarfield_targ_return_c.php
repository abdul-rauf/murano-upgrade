<?php
 // created: 2011-07-12 10:15:34
$dictionary['Lead']['fields']['targ_return_c']['enforced']='false';
$dictionary['Lead']['fields']['targ_return_c']['dependency']='';

 ?>