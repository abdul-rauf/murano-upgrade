<?php
// created: 2010-12-14 16:04:46
$layout_defs["Leads"]["subpanel_setup"]["leads_documents_2"] = array (
  'order' => 100,
  'module' => 'Documents',
  'subpanel_name' => '',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_LEADS_DOCUMENTS_2_FROM_DOCUMENTS_TITLE',
  'get_subpanel_data' => 'leads_documents_2',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
