<?php
//Workflow Action Meta Data Arrays 
$action_meta_array = array ( 

'Opportunities0_action0' => 

array ( 

		 'action_type' => 'new', 
		 'action_module' => 'project', 
		 'rel_module' => '', 
		 'rel_module_type' => 'all', 
	 'basic' => array ( 

		 'name' => 'New account', 
		 'estimated_start_date' => '0', 
		 'estimated_end_date' => '259200', 
	 ), 

	 'basic_ext' => array ( 

		 'estimated_start_date' => 'Triggered Date', 
		 'estimated_end_date' => 'Triggered Date', 
	 ), 

	 'advanced' => array ( 

	 ), 

), 

); 

 

?>