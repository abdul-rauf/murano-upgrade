<?php 
 // created: 2011-12-08 17:45:11
$mod_strings['LBL_MURANO'] = 'murano';

?>
