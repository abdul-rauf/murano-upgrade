<?php
// created: 2011-02-04 10:45:33
$dictionary["Account"]["fields"]["accounts_leads_2"] = array (
  'name' => 'accounts_leads_2',
  'type' => 'link',
  'relationship' => 'accounts_leads_2',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ACCOUNTS_LEADS_2_FROM_LEADS_TITLE',
);
