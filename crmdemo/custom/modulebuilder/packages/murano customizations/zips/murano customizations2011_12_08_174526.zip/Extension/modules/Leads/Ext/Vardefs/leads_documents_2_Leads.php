<?php
// created: 2010-12-14 16:04:46
$dictionary["Lead"]["fields"]["leads_documents_2"] = array (
  'name' => 'leads_documents_2',
  'type' => 'link',
  'relationship' => 'leads_documents_2',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_LEADS_DOCUMENTS_2_FROM_DOCUMENTS_TITLE',
);
