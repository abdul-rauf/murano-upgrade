<?php
// created: 2011-02-04 10:45:47
$layout_defs["Accounts"]["subpanel_setup"]["accounts_a79d3ccounts_ida"] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ACCOUNTS_ACCOUNTS_2_FROM_ACCOUNTS_R_TITLE',
  'get_subpanel_data' => 'accounts_a79d3ccounts_ida',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
