<?php
 // created: 2011-02-23 11:48:00
$dictionary['Call']['fields']['date_start']['required']=false;
$dictionary['Call']['fields']['date_start']['calculated']=false;
$dictionary['Call']['fields']['date_start']['importable']='true';
$dictionary['Call']['fields']['date_start']['display_default']='now&06:00pm';

 ?>