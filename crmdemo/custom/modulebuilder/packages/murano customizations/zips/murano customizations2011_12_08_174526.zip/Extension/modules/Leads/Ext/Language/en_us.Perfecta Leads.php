<?php 
 // created: 2011-02-09 16:41:50
$mod_strings['LBL_NOTES'] = 'Notes';
$mod_strings['LBL_NEWSLINKS'] = 'News Links';
$mod_strings['LBL_FSA'] = 'FSA';
$mod_strings['LBL_FUNDSTRATEGY'] = 'Fund Strategy';
$mod_strings['LBL_FUNDNAME'] = 'Fund Name';
$mod_strings['LBL_FUND_MANAGER'] = 'Fund Manager';
$mod_strings['LBL_AUM'] = 'AuM($mil)';
$mod_strings['LBL_AUM1'] = 'AuM($mil)';
$mod_strings['LNK_NEW_DOCUMENT'] = 'Create Document';
$mod_strings['LNK_SELECT_DOCUMENTS'] = ' <b>OR</b> Select Document';
$mod_strings['LBL_PANEL_ADVANCED'] = 'Lead Information';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Management & Fund Information';
$mod_strings['LBL_DESCRIPTION'] = 'Fund Description';
$mod_strings['LBL_FUND_TYPE'] = 'Fund Type';
$mod_strings['LBL_INVESTMENT_GEOGRAPHY'] = 'Investment Geography';
$mod_strings['LBL_OWNERSHIP'] = 'Ownership';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'Management & Fund Information';
$mod_strings['LBL_ALT_ADDRESS_STREET'] = 'Further Address Information';
$mod_strings['LBL_FURTHER_INFORMATION'] = 'Further Information';
$mod_strings['LBL_DETAILVIEW_PANEL2'] = 'New Panel 2';
$mod_strings['LBL_ACCOUNT_DESCRIPTION'] = 'Account Description';
$mod_strings['LNK_SELECT_LEADS'] = ' <b>OR</b> Select Lead';
$mod_strings['LBL_ALTERNATENAME'] = 'Alternate First Name';
$mod_strings['LBL_ALTERNATELASTNAME'] = 'Alternate Last Name';
$mod_strings['LBL_ALTERNATETITLE'] = 'Alternate Title';
$mod_strings['LNK_NEW_MC_MURANO_COMPANY'] = 'Create mc_Murano_Company';
$mod_strings['LNK_SELECT_MC_MURANO_COMPANY'] = ' <b>OR</b> Select mc_Murano_Company';
$mod_strings['LBL_PANEL_ASSIGNMENT'] = 'Management & Fund Information';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Account Name';

?>
