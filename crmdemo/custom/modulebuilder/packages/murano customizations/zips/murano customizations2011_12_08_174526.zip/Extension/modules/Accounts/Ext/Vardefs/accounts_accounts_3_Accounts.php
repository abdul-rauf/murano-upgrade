<?php
// created: 2011-02-04 10:45:50
$dictionary["Account"]["fields"]["accounts_accounts_3"] = array (
  'name' => 'accounts_accounts_3',
  'type' => 'link',
  'relationship' => 'accounts_accounts_3',
  'source' => 'non-db',
  'vname' => 'LBL_ACCOUNTS_ACCOUNTS_3_FROM_ACCOUNTS_L_TITLE',
);
$dictionary["Account"]["fields"]["accounts_accounts_3_name"] = array (
  'name' => 'accounts_accounts_3_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ACCOUNTS_ACCOUNTS_3_FROM_ACCOUNTS_L_TITLE',
  'save' => true,
  'id_name' => 'accounts_a3a34ccounts_ida',
  'link' => 'accounts_accounts_3',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
$dictionary["Account"]["fields"]["accounts_a3a34ccounts_ida"] = array (
  'name' => 'accounts_a3a34ccounts_ida',
  'type' => 'link',
  'relationship' => 'accounts_accounts_3',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_ACCOUNTS_ACCOUNTS_3_FROM_ACCOUNTS_R_TITLE',
);
