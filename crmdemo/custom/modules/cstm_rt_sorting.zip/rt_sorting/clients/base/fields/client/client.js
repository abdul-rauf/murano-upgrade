/**
 * Created by ahsan.latif on 6/30/16.
 */
({
    /**
     * Called when initializing the field
     * @param options
     */
    extendsFrom: 'NameField',
    _render: function () {

        this._super('_render');
        //console.log("test");
    },

})