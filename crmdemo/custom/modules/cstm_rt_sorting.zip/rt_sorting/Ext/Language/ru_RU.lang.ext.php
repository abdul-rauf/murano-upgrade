<?php
// WARNING: The contents of this file are auto-generated.

//Merged from custom/Extension/modules/rt_sorting/Ext/Language/ru_RU.Sorting.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_RT_SORTING_LEADS_FROM_LEADS_TITLE'] = 'Leads';
$mod_strings['LBL_RT_SORTING_LEADS_FROM_RT_SORTING_TITLE_ID'] = 'Leads ID';
