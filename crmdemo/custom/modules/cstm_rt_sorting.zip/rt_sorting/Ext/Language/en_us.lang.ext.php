<?php
// WARNING: The contents of this file are auto-generated.

//Merged from custom/Extension/modules/rt_sorting/Ext/Language/en_us.Sorting.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_RT_SORTING_LEADS_FROM_LEADS_TITLE'] = 'Name';
$mod_strings['LBL_RT_SORTING_LEADS_FROM_RT_SORTING_TITLE_ID'] = 'Leads ID';
$mod_strings['LBL_COMPOSE_CLIENT'] = 'Compose To Clients';
$mod_strings['LBL_RECENT_TIME_CHANGED'] = 'Recent Time Changed';

//Merged from custom/Extension/modules/rt_sorting/Ext/Language/en_us.lang.php

// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_LEAD_STATUS'] = 'Lead Status';
$mod_strings['LBL_POINTS'] = 'Lead Point';
$mod_strings['LBL_GREEN_POINT'] = 'Green Point';
$mod_strings['LBL_TOTAL_POINT'] = 'Total Point';
$mod_strings['LBL_GREENREPORT_C'] = 'Green Report?';
$mod_strings['LBL_FEEDBACK_DATE1_C'] = 'Completed Feedback Date';
$mod_strings['LBL_FEEDBACK_POINTS1_C'] = 'Feedback Points';
$mod_strings['LBL_NO_OF_DAYS_C'] = 'No of Days';
$mod_strings['LBL_FEEDBACK_RECEIVED'] = 'Feedback Received';
$mod_strings['LBL_ASSIGNED_TEAM'] = 'Assigned Team';
$mod_strings['LBL_POTENTIAL_CLIENTS'] = 'Search for Clients';
$mod_strings['LBL_CONFIRMED_CLIENTS'] = 'Confirmed Clients';
$mod_strings['LBL_QUESTION_MARKS'] = 'Question Marked';
$mod_strings['LBL_NAME'] = 'Subject';
$mod_strings['LBL_SPACES'] = 'Spaces';
$mod_strings['LBL_REPORT_STATUS'] = 'Report Status';
$mod_strings['LBL_AMENDMENTS_COMPLETED'] = 'Completed Amendments';
$mod_strings['LBL_AMENDMENTS'] = 'Amendments (Needs to be done)';
$mod_strings['LBL_EMAIL_TIMESTAMP'] = 'Email Timestamp';
$mod_strings['LBL_DATE_MODIFIED'] = 'Date Modified';
$mod_strings['LBL_DA_CONFIRMED_CLIENTS'] = 'DA Confirmed Clients';
$mod_strings['LBL_DA_QM_CLIENTS'] = 'DA Question Marks';
$mod_strings['LBL_DA_FEEDBACK_CLIENTS'] = 'DA Feedback Clients';
$mod_strings['LBL_OTHER_TEAM_CLIENT'] = 'Other Team Client?';
$mod_strings['LBL_REF_ID'] = 'Ref';
